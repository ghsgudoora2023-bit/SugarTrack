package com.example.data.repository

import com.example.data.SugarTrackDatabase
import com.example.data.entity.*
import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.*

class SugarTrackRepository(private val database: SugarTrackDatabase) {

    // Medicines
    val allMedicines: Flow<List<MedicineEntity>> = database.medicineDao().getAllMedicines()
    val lowStockMedicines: Flow<List<MedicineEntity>> = database.medicineDao().getLowStockMedicines()

    suspend fun insertMedicine(medicine: MedicineEntity): Long =
        database.medicineDao().insertMedicine(medicine)

    suspend fun updateMedicine(medicine: MedicineEntity) =
        database.medicineDao().updateMedicine(medicine)

    suspend fun deleteMedicine(medicine: MedicineEntity) =
        database.medicineDao().deleteMedicine(medicine)

    suspend fun markMedicineTaken(id: Long, taken: Boolean) {
        val now = System.currentTimeMillis()
        database.medicineDao().updateMedicineIntake(id, taken = taken, missed = false, timestamp = now)
    }

    suspend fun markMedicineMissed(id: Long, missed: Boolean) {
        database.medicineDao().updateMedicineIntake(id, taken = false, missed = missed, timestamp = 0L)
    }

    suspend fun refillStock(id: Long, count: Int) {
        database.medicineDao().refillStock(id, count)
    }

    // Sugar Logs
    val allSugarLogs: Flow<List<SugarLogEntity>> = database.sugarLogDao().getAllLogs()
    val latestSugarLog: Flow<SugarLogEntity?> = database.sugarLogDao().getLatestLog()

    fun getLogsForDate(date: String): Flow<List<SugarLogEntity>> =
        database.sugarLogDao().getLogsForDate(date)

    suspend fun insertSugarLog(log: SugarLogEntity): Long =
        database.sugarLogDao().insertLog(log)

    suspend fun deleteSugarLog(log: SugarLogEntity) =
        database.sugarLogDao().deleteLog(log)

    // HbA1c
    val allHbA1cRecords: Flow<List<HbA1cEntity>> = database.hba1cDao().getAllRecords()
    val latestHbA1c: Flow<HbA1cEntity?> = database.hba1cDao().getLatestRecord()

    suspend fun insertHbA1c(record: HbA1cEntity): Long =
        database.hba1cDao().insertRecord(record)

    suspend fun deleteHbA1c(record: HbA1cEntity) =
        database.hba1cDao().deleteRecord(record)

    // Blood Pressure
    val allBloodPressure: Flow<List<BloodPressureEntity>> = database.bloodPressureDao().getAllRecords()
    val latestBloodPressure: Flow<BloodPressureEntity?> = database.bloodPressureDao().getLatestRecord()

    suspend fun insertBloodPressure(record: BloodPressureEntity): Long =
        database.bloodPressureDao().insertRecord(record)

    suspend fun deleteBloodPressure(record: BloodPressureEntity) =
        database.bloodPressureDao().deleteRecord(record)

    // Weight
    val allWeightRecords: Flow<List<WeightEntity>> = database.weightDao().getAllRecords()

    suspend fun insertWeight(record: WeightEntity): Long =
        database.weightDao().insertRecord(record)

    suspend fun deleteWeight(record: WeightEntity) =
        database.weightDao().deleteRecord(record)

    // Appointments
    val allAppointments: Flow<List<AppointmentEntity>> = database.appointmentDao().getAllAppointments()

    suspend fun insertAppointment(appointment: AppointmentEntity): Long =
        database.appointmentDao().insertAppointment(appointment)

    suspend fun updateAppointment(appointment: AppointmentEntity) =
        database.appointmentDao().updateAppointment(appointment)

    suspend fun deleteAppointment(appointment: AppointmentEntity) =
        database.appointmentDao().deleteAppointment(appointment)

    // Prescriptions
    val allPrescriptions: Flow<List<PrescriptionEntity>> = database.prescriptionDao().getAllPrescriptions()

    suspend fun insertPrescription(prescription: PrescriptionEntity): Long =
        database.prescriptionDao().insertPrescription(prescription)

    suspend fun deletePrescription(prescription: PrescriptionEntity) =
        database.prescriptionDao().deletePrescription(prescription)

    // Family Members
    val allFamilyMembers: Flow<List<FamilyMemberEntity>> = database.familyDao().getAllMembers()

    suspend fun insertFamilyMember(member: FamilyMemberEntity): Long =
        database.familyDao().insertMember(member)

    suspend fun deleteFamilyMember(member: FamilyMemberEntity) =
        database.familyDao().deleteMember(member)

    // User Profile
    val userProfile: Flow<UserProfileEntity?> = database.profileDao().getProfile()

    suspend fun saveUserProfile(profile: UserProfileEntity) =
        database.profileDao().saveProfile(profile)
}
