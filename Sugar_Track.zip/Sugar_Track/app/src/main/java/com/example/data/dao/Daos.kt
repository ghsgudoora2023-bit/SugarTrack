package com.example.data.dao

import androidx.room.*
import com.example.data.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicineDao {
    @Query("SELECT * FROM medicines ORDER BY reminderHour ASC, reminderMinute ASC")
    fun getAllMedicines(): Flow<List<MedicineEntity>>

    @Query("SELECT * FROM medicines WHERE id = :id")
    suspend fun getMedicineById(id: Long): MedicineEntity?

    @Query("SELECT * FROM medicines WHERE quantityAvailable <= refillThreshold")
    fun getLowStockMedicines(): Flow<List<MedicineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: MedicineEntity): Long

    @Update
    suspend fun updateMedicine(medicine: MedicineEntity)

    @Delete
    suspend fun deleteMedicine(medicine: MedicineEntity)

    @Query("UPDATE medicines SET takenToday = :taken, missedToday = :missed, lastTakenTimestamp = :timestamp, quantityAvailable = CASE WHEN :taken = 1 AND quantityAvailable > 0 THEN quantityAvailable - 1 ELSE quantityAvailable END WHERE id = :id")
    suspend fun updateMedicineIntake(id: Long, taken: Boolean, missed: Boolean, timestamp: Long)

    @Query("UPDATE medicines SET quantityAvailable = quantityAvailable + :count WHERE id = :id")
    suspend fun refillStock(id: Long, count: Int)

    @Query("UPDATE medicines SET takenToday = 0, missedToday = 0")
    suspend fun resetDailyStatus()
}

@Dao
interface SugarLogDao {
    @Query("SELECT * FROM sugar_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<SugarLogEntity>>

    @Query("SELECT * FROM sugar_logs WHERE date = :date ORDER BY timestamp DESC")
    fun getLogsForDate(date: String): Flow<List<SugarLogEntity>>

    @Query("SELECT * FROM sugar_logs ORDER BY timestamp DESC LIMIT 1")
    fun getLatestLog(): Flow<SugarLogEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: SugarLogEntity): Long

    @Delete
    suspend fun deleteLog(log: SugarLogEntity)

    @Query("SELECT AVG(value) FROM sugar_logs WHERE timestamp >= :sinceTimestamp")
    fun getAverageSugarSince(sinceTimestamp: Long): Flow<Double?>
}

@Dao
interface HbA1cDao {
    @Query("SELECT * FROM hba1c_records ORDER BY timestamp DESC")
    fun getAllRecords(): Flow<List<HbA1cEntity>>

    @Query("SELECT * FROM hba1c_records ORDER BY timestamp DESC LIMIT 1")
    fun getLatestRecord(): Flow<HbA1cEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: HbA1cEntity): Long

    @Delete
    suspend fun deleteRecord(record: HbA1cEntity)
}

@Dao
interface BloodPressureDao {
    @Query("SELECT * FROM blood_pressure_records ORDER BY timestamp DESC")
    fun getAllRecords(): Flow<List<BloodPressureEntity>>

    @Query("SELECT * FROM blood_pressure_records ORDER BY timestamp DESC LIMIT 1")
    fun getLatestRecord(): Flow<BloodPressureEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: BloodPressureEntity): Long

    @Delete
    suspend fun deleteRecord(record: BloodPressureEntity)
}

@Dao
interface WeightDao {
    @Query("SELECT * FROM weight_records ORDER BY timestamp DESC")
    fun getAllRecords(): Flow<List<WeightEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecord(record: WeightEntity): Long

    @Delete
    suspend fun deleteRecord(record: WeightEntity)
}

@Dao
interface AppointmentDao {
    @Query("SELECT * FROM appointments ORDER BY date ASC, time ASC")
    fun getAllAppointments(): Flow<List<AppointmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAppointment(appointment: AppointmentEntity): Long

    @Update
    suspend fun updateAppointment(appointment: AppointmentEntity)

    @Delete
    suspend fun deleteAppointment(appointment: AppointmentEntity)
}

@Dao
interface PrescriptionDao {
    @Query("SELECT * FROM prescriptions ORDER BY timestamp DESC")
    fun getAllPrescriptions(): Flow<List<PrescriptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrescription(prescription: PrescriptionEntity): Long

    @Delete
    suspend fun deletePrescription(prescription: PrescriptionEntity)
}

@Dao
interface FamilyDao {
    @Query("SELECT * FROM family_members ORDER BY name ASC")
    fun getAllMembers(): Flow<List<FamilyMemberEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMember(member: FamilyMemberEntity): Long

    @Delete
    suspend fun deleteMember(member: FamilyMemberEntity)
}

@Dao
interface ProfileDao {
    @Query("SELECT * FROM user_profile WHERE id = 1 LIMIT 1")
    fun getProfile(): Flow<UserProfileEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProfile(profile: UserProfileEntity)
}
