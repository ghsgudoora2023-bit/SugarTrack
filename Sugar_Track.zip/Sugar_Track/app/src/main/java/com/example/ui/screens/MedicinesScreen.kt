package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.MedicineEntity
import com.example.ui.components.RefillAlertCard
import com.example.ui.theme.*
import com.example.viewmodel.SugarTrackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicinesScreen(viewModel: SugarTrackViewModel) {
    val medicines by viewModel.medicines.collectAsState()
    val lowStockMeds by viewModel.lowStockMedicines.collectAsState()
    val isSenior by viewModel.isSeniorMode.collectAsState()

    var selectedScreenTab by remember { mutableStateOf(0) } // 0 = Schedule, 1 = Taken History & Adherence
    var selectedCategoryFilter by remember { mutableStateOf("All") }
    val categories = listOf("All", "Tablet", "Capsule", "Insulin", "Injection", "Syrup", "Drops")

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingMedicine by remember { mutableStateOf<MedicineEntity?>(null) }
    var showDeleteConfirmDialog by remember { mutableStateOf<MedicineEntity?>(null) }
    var viewingMedicineDetail by remember { mutableStateOf<MedicineEntity?>(null) }

    val filteredMedicines = remember(medicines, selectedCategoryFilter) {
        if (selectedCategoryFilter == "All") medicines
        else medicines.filter { it.category.equals(selectedCategoryFilter, ignoreCase = true) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Medicine Management",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 22.sp else 19.sp,
                        color = MedicalBluePrimary
                    )
                },
                actions = {
                    IconButton(
                        onClick = {
                            editingMedicine = null
                            showAddEditDialog = true
                        },
                        modifier = Modifier.testTag("add_medicine_button")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Add Medicine", tint = MedicalBluePrimary, modifier = Modifier.size(28.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            if (selectedScreenTab == 0) {
                ExtendedFloatingActionButton(
                    onClick = {
                        editingMedicine = null
                        showAddEditDialog = true
                    },
                    containerColor = MedicalBluePrimary,
                    contentColor = Color.White,
                    icon = { Icon(Icons.Default.Add, contentDescription = null) },
                    text = { Text("Add Medicine", fontWeight = FontWeight.Bold) },
                    modifier = Modifier.testTag("fab_add_medicine")
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Screen Tabs
            TabRow(
                selectedTabIndex = selectedScreenTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MedicalBluePrimary
            ) {
                Tab(
                    selected = selectedScreenTab == 0,
                    onClick = { selectedScreenTab = 0 },
                    text = {
                        Text(
                            "Daily Schedule (${medicines.size})",
                            fontWeight = if (selectedScreenTab == 0) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (isSenior) 15.sp else 13.sp
                        )
                    }
                )
                Tab(
                    selected = selectedScreenTab == 1,
                    onClick = { selectedScreenTab = 1 },
                    text = {
                        Text(
                            "Taken History & Adherence",
                            fontWeight = if (selectedScreenTab == 1) FontWeight.Bold else FontWeight.Normal,
                            fontSize = if (isSenior) 15.sp else 13.sp
                        )
                    }
                )
            }

            if (selectedScreenTab == 0) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 10.dp, bottom = 88.dp)
                ) {
                    // Category Filter Chips
                    item {
                        LazyRow(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(categories) { cat ->
                                FilterChip(
                                    selected = selectedCategoryFilter == cat,
                                    onClick = { selectedCategoryFilter = cat },
                                    label = { Text(cat, fontSize = if (isSenior) 14.sp else 12.sp) }
                                )
                            }
                        }
                    }

                    // Low Stock Refill Warning Section
                    if (lowStockMeds.isNotEmpty()) {
                        item {
                            Text(
                                "Stock & Refill Alerts",
                                fontWeight = FontWeight.Bold,
                                color = SugarHighAlertOrange,
                                fontSize = if (isSenior) 16.sp else 13.sp
                            )
                        }
                        items(lowStockMeds) { med ->
                            RefillAlertCard(
                                medicineName = med.name,
                                stockLeft = med.quantityAvailable,
                                onRefillClick = { viewModel.refillMedicine(med, 30) }
                            )
                        }
                    }

                    // Medicine List
                    item {
                        Text(
                            "All Scheduled Medicines (${filteredMedicines.size})",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 18.sp else 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    if (filteredMedicines.isEmpty()) {
                        item {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                            ) {
                                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                                    Text("No medicines found under '$selectedCategoryFilter'. Tap '+' to add one.")
                                }
                            }
                        }
                    } else {
                        items(filteredMedicines, key = { it.id }) { med ->
                            MedicineDetailCard(
                                medicine = med,
                                isSenior = isSenior,
                                onCardClick = { viewingMedicineDetail = med },
                                onTaken = { viewModel.markMedicineTaken(med) },
                                onSnooze = { viewModel.snoozeMedicine(med, 15) },
                                onMissed = { viewModel.markMedicineMissed(med) },
                                onEdit = {
                                    editingMedicine = med
                                    showAddEditDialog = true
                                },
                                onDelete = { showDeleteConfirmDialog = med },
                                onRefill = { viewModel.refillMedicine(med, 30) },
                                onTestReminder = { viewModel.testReminderNotification(med) }
                            )
                        }
                    }
                }
            } else {
                // Tab 1: Taken History & Adherence
                val takenCount = medicines.count { it.takenToday }
                val missedCount = medicines.count { it.missedToday }
                val totalMeds = medicines.size
                val adherencePercent = if (totalMeds == 0) 100 else ((takenCount.toFloat() / totalMeds) * 100).toInt()

                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(top = 14.dp, bottom = 88.dp)
                ) {
                    // Adherence Summary Card
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "Medication Adherence",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = if (isSenior) 19.sp else 16.sp,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        "$adherencePercent%",
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = if (isSenior) 28.sp else 24.sp,
                                        color = if (adherencePercent >= 80) SugarNormalGreen else SugarHighAlertOrange
                                    )
                                }
                                Spacer(Modifier.height(8.dp))
                                LinearProgressIndicator(
                                    progress = { (adherencePercent / 100f).coerceIn(0f, 1f) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = if (adherencePercent >= 80) SugarNormalGreen else SugarHighAlertOrange,
                                    trackColor = MaterialTheme.colorScheme.surface
                                )
                                Spacer(Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("✓ Taken Today: $takenCount", fontSize = 12.sp, color = SugarNormalGreen, fontWeight = FontWeight.SemiBold)
                                    Text("✕ Missed Today: $missedCount", fontSize = 12.sp, color = SugarLowAlertRed, fontWeight = FontWeight.SemiBold)
                                    Text("⏱️ Total: $totalMeds", fontSize = 12.sp, color = Color.Gray)
                                }
                            }
                        }
                    }

                    item {
                        Text(
                            "Today's Dose Log",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 18.sp else 15.sp
                        )
                    }

                    items(medicines) { med ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when {
                                                    med.takenToday -> SugarNormalGreen.copy(alpha = 0.15f)
                                                    med.missedToday -> SugarLowAlertRed.copy(alpha = 0.15f)
                                                    else -> Color.LightGray.copy(alpha = 0.3f)
                                                }
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when {
                                                med.takenToday -> Icons.Default.CheckCircle
                                                med.missedToday -> Icons.Default.Cancel
                                                else -> Icons.Default.Schedule
                                            },
                                            contentDescription = null,
                                            tint = when {
                                                med.takenToday -> SugarNormalGreen
                                                med.missedToday -> SugarLowAlertRed
                                                else -> Color.Gray
                                            },
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            med.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = if (isSenior) 16.sp else 14.sp
                                        )
                                        Text(
                                            "${med.dosage} • ${med.reminderTime} • ${med.frequency}",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Text(
                                    text = when {
                                        med.takenToday -> "Taken ✓"
                                        med.missedToday -> "Missed ✕"
                                        else -> "Pending"
                                    },
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        med.takenToday -> SugarNormalGreen
                                        med.missedToday -> SugarLowAlertRed
                                        else -> Color.Gray
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Medicine Detail Screen Dialog
    viewingMedicineDetail?.let { med ->
        MedicineDetailDialog(
            medicine = med,
            isSenior = isSenior,
            onDismiss = { viewingMedicineDetail = null },
            onTaken = {
                viewModel.markMedicineTaken(med)
                viewingMedicineDetail = null
            },
            onSnooze = {
                viewModel.snoozeMedicine(med, 15)
                viewingMedicineDetail = null
            },
            onMissed = {
                viewModel.markMedicineMissed(med)
                viewingMedicineDetail = null
            },
            onRefill = {
                viewModel.refillMedicine(med, 30)
                viewingMedicineDetail = null
            },
            onEdit = {
                viewingMedicineDetail = null
                editingMedicine = med
                showAddEditDialog = true
            }
        )
    }

    // Add / Edit Dialog
    if (showAddEditDialog) {
        AddEditMedicineDialog(
            existing = editingMedicine,
            onDismiss = { showAddEditDialog = false },
            onSave = { updated ->
                if (editingMedicine == null) {
                    viewModel.addMedicine(updated)
                } else {
                    viewModel.updateMedicine(updated)
                }
                showAddEditDialog = false
            }
        )
    }

    // Delete Confirmation Dialog
    showDeleteConfirmDialog?.let { med ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Delete Medicine") },
            text = { Text("Are you sure you want to remove ${med.name} from your schedule?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteMedicine(med)
                        showDeleteConfirmDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SugarLowAlertRed)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun MedicineDetailCard(
    medicine: MedicineEntity,
    isSenior: Boolean,
    onCardClick: () -> Unit,
    onTaken: () -> Unit,
    onSnooze: () -> Unit,
    onMissed: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onRefill: () -> Unit,
    onTestReminder: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onCardClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: Name, Category Tag, Overflow menu/edit
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(if (isSenior) 44.dp else 36.dp)
                            .clip(CircleShape)
                            .background(MedicalBluePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (medicine.category) {
                                "Insulin" -> Icons.Default.Vaccines
                                "Syrup" -> Icons.Default.LocalDrink
                                else -> Icons.Default.Medication
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(if (isSenior) 24.dp else 20.dp)
                        )
                    }

                    Spacer(Modifier.width(12.dp))

                    Column {
                        Text(
                            text = medicine.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 19.sp else 16.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${medicine.dosage} • ${medicine.category}",
                                fontSize = if (isSenior) 14.sp else 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Row {
                    IconButton(onClick = onTestReminder, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Outlined.Notifications, contentDescription = "Test Notification", tint = MedicalBlueLight)
                    }
                    IconButton(onClick = onEdit, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = Color.Gray)
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = SugarLowAlertRed)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Details info row: Frequency & Stock Available
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AccessTime, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Gray)
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = "${medicine.reminderTime} (${medicine.frequency})",
                        fontSize = if (isSenior) 14.sp else 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Stock pill
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Stock: ${medicine.quantityAvailable} left",
                        fontSize = if (isSenior) 14.sp else 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (medicine.quantityAvailable <= medicine.refillThreshold) SugarHighAlertOrange else SugarNormalGreen
                    )
                    Spacer(Modifier.width(6.dp))
                    IconButton(onClick = onRefill, modifier = Modifier.size(24.dp)) {
                        Icon(Icons.Default.AddCircleOutline, contentDescription = "Refill", tint = MedicalBluePrimary)
                    }
                }
            }

            if (medicine.notes.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "Note: ${medicine.notes}",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                )
            }

            Spacer(Modifier.height(12.dp))

            // Action Buttons: Mark Taken / Snooze / Missed
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onTaken,
                    modifier = Modifier.weight(1.2f).height(if (isSenior) 48.dp else 40.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (medicine.takenToday) SugarNormalGreen else MedicalBluePrimary
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(if (medicine.takenToday) "Taken ✓" else "Take", fontSize = if (isSenior) 14.sp else 12.sp)
                }

                OutlinedButton(
                    onClick = onSnooze,
                    modifier = Modifier.weight(1f).height(if (isSenior) 48.dp else 40.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MedicalBlueLight),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(Modifier.width(3.dp))
                    Text("Snooze", fontSize = if (isSenior) 13.sp else 11.sp)
                }

                OutlinedButton(
                    onClick = onMissed,
                    modifier = Modifier.weight(0.9f).height(if (isSenior) 48.dp else 40.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (medicine.missedToday) SugarLowAlertRed else Color.Gray
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(if (medicine.missedToday) "Missed ✕" else "Miss", fontSize = if (isSenior) 13.sp else 11.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMedicineDialog(
    existing: MedicineEntity?,
    onDismiss: () -> Unit,
    onSave: (MedicineEntity) -> Unit
) {
    var name by remember { mutableStateOf(existing?.name ?: "") }
    var dosage by remember { mutableStateOf(existing?.dosage ?: "500 mg") }
    var frequency by remember { mutableStateOf(existing?.frequency ?: "Once Daily") }
    var category by remember { mutableStateOf(existing?.category ?: "Tablet") }
    var mealTiming by remember { mutableStateOf("After Food") }
    var quantityStr by remember { mutableStateOf(existing?.quantityAvailable?.toString() ?: "30") }
    var reminderTime by remember { mutableStateOf(existing?.reminderTime ?: "08:00 AM") }
    var notes by remember { mutableStateOf(existing?.notes ?: "") }

    val categories = listOf("Tablet", "Capsule", "Insulin", "Injection", "Syrup", "Drops")
    val frequencies = listOf("Once Daily", "Twice Daily", "Thrice Daily", "As Needed")
    val timings = listOf("Before Food", "After Food", "With Food", "Empty Stomach", "Bedtime")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (existing == null) "Add New Medicine" else "Edit Medicine", fontWeight = FontWeight.Bold)
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Medicine Name (e.g. Metformin)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().testTag("input_medicine_name"),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dosage,
                            onValueChange = { dosage = it },
                            label = { Text("Dosage (e.g. 500mg, 10 units)") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                        OutlinedTextField(
                            value = quantityStr,
                            onValueChange = { quantityStr = it },
                            label = { Text("Stock Quantity") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }

                item {
                    Text("Type / Form:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(categories) { cat ->
                            FilterChip(
                                selected = category == cat,
                                onClick = { category = cat },
                                label = { Text(cat, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Text("Frequency:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(frequencies) { freq ->
                            FilterChip(
                                selected = frequency == freq,
                                onClick = { frequency = freq },
                                label = { Text(freq, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    Text("Meal Timing:", style = MaterialTheme.typography.labelMedium)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(timings) { timeOpt ->
                            FilterChip(
                                selected = mealTiming == timeOpt,
                                onClick = { mealTiming = timeOpt },
                                label = { Text(timeOpt, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = reminderTime,
                        onValueChange = { reminderTime = it },
                        label = { Text("Reminder Time (e.g. 08:00 AM)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                item {
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Doctor's notes / instructions") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val combinedNotes = if (notes.isBlank()) mealTiming else "$mealTiming • $notes"
                        val entity = existing?.copy(
                            name = name,
                            dosage = dosage,
                            frequency = frequency,
                            category = category,
                            quantityAvailable = quantityStr.toIntOrNull() ?: 30,
                            reminderTime = reminderTime,
                            notes = combinedNotes
                        ) ?: MedicineEntity(
                            name = name,
                            dosage = dosage,
                            frequency = frequency,
                            category = category,
                            quantityAvailable = quantityStr.toIntOrNull() ?: 30,
                            reminderTime = reminderTime,
                            startDate = "Today",
                            notes = combinedNotes
                        )
                        onSave(entity)
                    }
                },
                modifier = Modifier.testTag("save_medicine_button")
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun MedicineDetailDialog(
    medicine: MedicineEntity,
    isSenior: Boolean,
    onDismiss: () -> Unit,
    onTaken: () -> Unit,
    onSnooze: () -> Unit,
    onMissed: () -> Unit,
    onRefill: () -> Unit,
    onEdit: () -> Unit
) {
    val isLowStock = medicine.quantityAvailable <= medicine.refillThreshold

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(MedicalBluePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (medicine.category) {
                                "Insulin" -> Icons.Default.Vaccines
                                "Syrup" -> Icons.Default.LocalDrink
                                else -> Icons.Default.Medication
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Text(
                            text = medicine.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 22.sp else 18.sp
                        )
                        Text(
                            text = "${medicine.dosage} • ${medicine.category}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                IconButton(onClick = onEdit) {
                    Icon(Icons.Default.Edit, contentDescription = "Edit Medicine", tint = MedicalBlueLight)
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Next Reminder Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Alarm,
                            contentDescription = null,
                            tint = MedicalBluePrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text("Scheduled Reminder", fontSize = 11.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                text = "${medicine.reminderTime} • ${medicine.frequency}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MedicalBluePrimary
                            )
                        }
                    }
                }

                // Remaining Quantity & Refill Alert
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isLowStock) SugarHighAlertOrangeBg else MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Remaining Stock",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = if (isLowStock) SugarHighAlertOrange else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${medicine.quantityAvailable} doses left",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isLowStock) SugarHighAlertOrange else SugarNormalGreen
                                )
                                Spacer(Modifier.width(8.dp))
                                Button(
                                    onClick = onRefill,
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = MedicalBluePrimary)
                                ) {
                                    Text("+30 Refill", fontSize = 11.sp)
                                }
                            }
                        }

                        if (isLowStock) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                text = "⚠️ Low stock alert! Quantity reached alert threshold (${medicine.refillThreshold} doses). Please refill soon.",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                // Instructions & Doctor Notes
                if (medicine.notes.isNotBlank()) {
                    Column {
                        Text("Instructions / Doctor Notes", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            text = medicine.notes,
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Divider(color = MaterialTheme.colorScheme.outlineVariant)

                // Dose Actions: Taken, Snooze, Missed
                Text("Log Dose Action:", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = onTaken,
                        modifier = Modifier.weight(1.2f).height(44.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (medicine.takenToday) SugarNormalGreen else MedicalBluePrimary
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text(if (medicine.takenToday) "Taken ✓" else "Taken")
                    }

                    OutlinedButton(
                        onClick = onSnooze,
                        modifier = Modifier.weight(1f).height(44.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MedicalBlueLight),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(3.dp))
                        Text("Snooze")
                    }

                    OutlinedButton(
                        onClick = onMissed,
                        modifier = Modifier.weight(0.9f).height(44.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = if (medicine.missedToday) SugarLowAlertRed else Color.Gray
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(if (medicine.missedToday) "Missed ✕" else "Miss")
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
