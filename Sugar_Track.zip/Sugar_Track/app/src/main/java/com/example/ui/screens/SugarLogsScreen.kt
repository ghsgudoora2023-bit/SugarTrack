package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.SugarLogEntity
import com.example.ui.components.GlucoseStatusBadge
import com.example.ui.components.GlucoseTrendChart
import com.example.ui.theme.*
import com.example.viewmodel.SugarTrackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SugarLogsScreen(viewModel: SugarTrackViewModel) {
    val sugarLogs by viewModel.sugarLogs.collectAsState()
    val isSenior by viewModel.isSeniorMode.collectAsState()

    var isMmolUnit by remember { mutableStateOf(false) } // false = mg/dL, true = mmol/L
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedRange by remember { mutableStateOf("7d") } // "7d", "30d", "90d", "all"
    var showDeleteConfirmDialog by remember { mutableStateOf<SugarLogEntity?>(null) }

    val filteredLogs = remember(sugarLogs, selectedRange) {
        val now = System.currentTimeMillis()
        val oneDay = 86_400_000L
        when (selectedRange) {
            "7d" -> sugarLogs.filter { now - it.timestamp <= 7 * oneDay }
            "30d" -> sugarLogs.filter { now - it.timestamp <= 30 * oneDay }
            "90d" -> sugarLogs.filter { now - it.timestamp <= 90 * oneDay }
            else -> sugarLogs
        }
    }

    // Analytics calculations
    val averageSugar = remember(filteredLogs) {
        if (filteredLogs.isEmpty()) 0.0 else filteredLogs.map { it.value }.average()
    }
    val inRangeCount = remember(filteredLogs) {
        filteredLogs.count { it.value in 70.0..140.0 }
    }
    val inRangePercent = remember(filteredLogs, inRangeCount) {
        if (filteredLogs.isEmpty()) 0 else (inRangeCount * 100 / filteredLogs.size)
    }
    val hypoCount = remember(filteredLogs) {
        filteredLogs.count { it.value < 70.0 }
    }
    val hyperCount = remember(filteredLogs) {
        filteredLogs.count { it.value > 180.0 }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Blood Sugar Logs & Analytics",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 22.sp else 19.sp,
                        color = MedicalBluePrimary
                    )
                },
                actions = {
                    // Unit Toggle Chip
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .clickable { isMmolUnit = !isMmolUnit }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = if (isMmolUnit) "mmol/L" else "mg/dL",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = MedicalBluePrimary
                        )
                        Spacer(Modifier.width(2.dp))
                        Icon(Icons.Default.SwapHoriz, contentDescription = "Switch Unit", tint = MedicalBluePrimary, modifier = Modifier.size(14.dp))
                    }

                    Spacer(Modifier.width(4.dp))

                    IconButton(
                        onClick = { showAddDialog = true },
                        modifier = Modifier.testTag("add_sugar_button")
                    ) {
                        Icon(Icons.Default.AddCircle, contentDescription = "Log Sugar", tint = MedicalBluePrimary, modifier = Modifier.size(28.dp))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MedicalBluePrimary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Log Reading", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("fab_log_reading")
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 88.dp)
        ) {
            // Range Filter Tabs
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val ranges = listOf("7d" to "7 Days", "30d" to "30 Days", "90d" to "90 Days", "all" to "All Time")
                    ranges.forEach { (code, label) ->
                        FilterChip(
                            selected = selectedRange == code,
                            onClick = { selectedRange = code },
                            label = { Text(label, fontSize = if (isSenior) 13.sp else 11.sp) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Target Range Guidelines Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Standard Target Ranges",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 14.sp else 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                if (isMmolUnit) "Unit: mmol/L" else "Unit: mg/dL",
                                fontSize = 11.sp,
                                color = MedicalBluePrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Fasting / Pre-Meal", fontSize = 10.sp, color = Color.Gray)
                                Text(
                                    if (isMmolUnit) "3.9 – 5.6" else "70 – 100",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SugarNormalGreen
                                )
                            }
                            Column {
                                Text("Post-Meal (2 hrs)", fontSize = 10.sp, color = Color.Gray)
                                Text(
                                    if (isMmolUnit) "< 7.8" else "< 140",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SugarNormalGreen
                                )
                            }
                            Column {
                                Text("Hypo Alert", fontSize = 10.sp, color = Color.Gray)
                                Text(
                                    if (isMmolUnit) "< 3.9" else "< 70",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SugarLowAlertRed
                                )
                            }
                            Column {
                                Text("High Alert", fontSize = 10.sp, color = Color.Gray)
                                Text(
                                    if (isMmolUnit) "> 10.0" else "> 180",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = SugarHighAlertOrange
                                )
                            }
                        }
                    }
                }
            }

            // Analytics Dashboard Cards (Averages, In-Target, Alerts)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Analytics Summary (${when(selectedRange){ "7d" -> "Last 7 Days"; "30d" -> "Last 30 Days"; "90d" -> "Last 90 Days"; else -> "All" }})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Average
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Average", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    text = if (averageSugar > 0) {
                                        if (isMmolUnit) String.format(java.util.Locale.US, "%.1f", averageSugar / 18.0182)
                                        else "${averageSugar.toInt()}"
                                    } else "--",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MedicalBluePrimary
                                )
                                Text(if (isMmolUnit) "mmol/L" else "mg/dL", fontSize = 10.sp, color = Color.Gray)
                            }

                            // In Target %
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("In Range (70-140)", fontSize = 11.sp, color = Color.Gray)
                                Text(
                                    text = "$inRangePercent%",
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SugarNormalGreen
                                )
                                Text("$inRangeCount readings", fontSize = 10.sp, color = Color.Gray)
                            }

                            // Hypo / Hyper
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Out of Range", fontSize = 11.sp, color = Color.Gray)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("▼$hypoCount", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = SugarLowAlertRed)
                                    Spacer(Modifier.width(8.dp))
                                    Text("▲$hyperCount", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = SugarHighAlertOrange)
                                }
                                Text("Low / High", fontSize = 10.sp, color = Color.Gray)
                            }
                        }

                        Spacer(Modifier.height(16.dp))

                        // Visual Trend Chart
                        GlucoseTrendChart(
                            logs = filteredLogs,
                            heightDp = if (isSenior) 190 else 160
                        )
                    }
                }
            }

            // History Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Reading History (${filteredLogs.size})",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 19.sp else 16.sp
                    )
                    Text(
                        "Latest first",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }

            // Reading Items
            if (filteredLogs.isEmpty()) {
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                            Text("No readings logged in this timeframe. Tap 'Log Reading' to add.")
                        }
                    }
                }
            } else {
                items(filteredLogs, key = { it.id }) { log ->
                    SugarLogHistoryItem(
                        log = log,
                        isSenior = isSenior,
                        isMmolUnit = isMmolUnit,
                        onDelete = { showDeleteConfirmDialog = log }
                    )
                }
            }
        }
    }

    if (showAddDialog) {
        AddSugarLogDialog(
            onDismiss = { showAddDialog = false },
            onSave = { v, t, n ->
                viewModel.addSugarReading(v, t, n)
                showAddDialog = false
            },
            isSenior = isSenior
        )
    }

    showDeleteConfirmDialog?.let { log ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Delete Reading") },
            text = { Text("Delete reading of ${log.value.toInt()} mg/dL logged on ${log.date} ${log.time}?") },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteSugarLog(log)
                        showDeleteConfirmDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SugarLowAlertRed)
                ) {
                    Text("Delete")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun SugarLogHistoryItem(
    log: SugarLogEntity,
    isSenior: Boolean,
    isMmolUnit: Boolean,
    onDelete: () -> Unit
) {
    val displayValue = if (isMmolUnit) {
        String.format(java.util.Locale.US, "%.1f", log.value / 18.0182)
    } else {
        "${log.value.toInt()}"
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Value Circle badge
                Box(
                    modifier = Modifier
                        .size(if (isSenior) 58.dp else 48.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                log.value < 70 -> SugarLowAlertRedBg
                                log.value <= 140 -> SugarNormalGreenBg
                                else -> SugarHighAlertOrangeBg
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = displayValue,
                            fontSize = if (isSenior) 18.sp else 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                log.value < 70 -> SugarLowAlertRed
                                log.value <= 140 -> SugarNormalGreen
                                else -> SugarHighAlertOrange
                            }
                        )
                        Text(
                            text = if (isMmolUnit) "mmol" else "mg/dL",
                            fontSize = 8.sp,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = log.readingType,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 14.sp
                        )
                        Spacer(Modifier.width(6.dp))
                        GlucoseStatusBadge(value = log.value, isSenior = isSenior)
                    }
                    Text(
                        text = "${log.date} at ${log.time}",
                        fontSize = if (isSenior) 13.sp else 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    if (log.notes.isNotBlank()) {
                        Text(
                            text = log.notes,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                }
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
            }
        }
    }
}
