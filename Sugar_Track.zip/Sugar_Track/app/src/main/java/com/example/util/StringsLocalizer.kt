package com.example.util

object StringsLocalizer {

    enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
        ENGLISH("en", "English", "English"),
        HINDI("hi", "Hindi", "हिंदी"),
        URDU("ur", "Urdu", "اردو"),
        KASHMIRI("ks", "Kashmiri", "کٲشُر")
    }

    private val translations = mapOf(
        "app_name" to mapOf(
            "en" to "SugarTrack",
            "hi" to "शुगरट्रैक",
            "ur" to "شوگر ٹریک",
            "ks" to "شوگر ٹریک"
        ),
        "tagline" to mapOf(
            "en" to "Track Sugar. Track Health.",
            "hi" to "शुगर ट्रैक करें। सेहत ट्रैक करें।",
            "ur" to "شوگر ٹریک کریں۔ صحت سنبھالیں۔",
            "ks" to "شوگر کٔرو ٹریک۔ صحت تھاوِو برقرار۔"
        ),
        "nav_home" to mapOf(
            "en" to "Home",
            "hi" to "होम",
            "ur" to "ہوم",
            "ks" to "گھر"
        ),
        "nav_medicines" to mapOf(
            "en" to "Medicines",
            "hi" to "दवाइयां",
            "ur" to "دوائیں",
            "ks" to "دواہ"
        ),
        "nav_sugar_logs" to mapOf(
            "en" to "Sugar Logs",
            "hi" to "शुगर लॉग",
            "ur" to "شوگر لاگز",
            "ks" to "شوگر ریکارڈ"
        ),
        "nav_reports" to mapOf(
            "en" to "Reports",
            "hi" to "रिपोर्ट्स",
            "ur" to "رپورٹس",
            "ks" to "رپورٹ"
        ),
        "nav_profile" to mapOf(
            "en" to "Profile",
            "hi" to "प्रोफाइल",
            "ur" to "پروفائل",
            "ks" to "پروفائل"
        ),
        "senior_mode" to mapOf(
            "en" to "Senior Mode (Elderly Friendly)",
            "hi" to "वरिष्ठ मोड (सरल और बड़े अक्षर)",
            "ur" to "سینئر موڈ (بڑے اور آسان الفاظ)",
            "ks" to "سینئر موڈ (بۆڈ فونٹ تہٕ آسان)"
        ),
        "quick_emergency" to mapOf(
            "en" to "Emergency Doctor Call",
            "hi" to "आपातकालीन डॉक्टर कॉल",
            "ur" to "ایمرجنسی ڈاکٹر کال",
            "ks" to "ہنگامی ڈاکٹر رابطہ"
        ),
        "due_today" to mapOf(
            "en" to "Medicines Due Today",
            "hi" to "आज की दवाइयां",
            "ur" to "آج کی دوائیں",
            "ks" to "ازچؠ دواہ"
        ),
        "mark_taken" to mapOf(
            "en" to "Mark Taken",
            "hi" to "ले ली",
            "ur" to "لے لی",
            "ks" to "خیے"
        ),
        "mark_missed" to mapOf(
            "en" to "Mark Missed",
            "hi" to "छूट गई",
            "ur" to "چھوٹ گئی",
            "ks" to "مُکلیے"
        ),
        "refill_alert" to mapOf(
            "en" to "Low Stock Refill Alert",
            "hi" to "दवा खत्म होने वाली है",
            "ur" to "دوا ختم ہونے کا انتباہ",
            "ks" to "دواہ چھُ ختم گژھان"
        ),
        "sugar_trend" to mapOf(
            "en" to "Blood Sugar Trend",
            "hi" to "रक्त शर्करा रुझान",
            "ur" to "بلڈ شوگر کا رجحان",
            "ks" to "خونک شوگر ٹرینڈ"
        ),
        "fasting" to mapOf(
            "en" to "Fasting",
            "hi" to "खाली पेट",
            "ur" to "نہار منہ",
            "ks" to "نہار پیٹھ"
        ),
        "before_meal" to mapOf(
            "en" to "Before Meal",
            "hi" to "खाने से पहले",
            "ur" to "کھانے سے پہلے",
            "ks" to "کھؠنہٕ برونٛہہ"
        ),
        "after_meal" to mapOf(
            "en" to "After Meal",
            "hi" to "खाने के बाद",
            "ur" to "کھانے کے بعد",
            "ks" to "کھؠنہٕ پتہٕ"
        ),
        "random" to mapOf(
            "en" to "Random",
            "hi" to "किसी भी समय",
            "ur" to "کسی بھی وقت",
            "ks" to "کہنہہ تہِ وقت"
        ),
        "add_reading" to mapOf(
            "en" to "Log Blood Sugar",
            "hi" to "शुगर दर्ज करें",
            "ur" to "شوگر درج کریں",
            "ks" to "شوگر تھاوِو درج"
        ),
        "generate_pdf" to mapOf(
            "en" to "Generate & Share PDF Report",
            "hi" to "PDF रिपोर्ट बनाएं और भेजें",
            "ur" to "پی ڈی ایف رپورٹ بنائیں اور بھیجیں",
            "ks" to "پی ڈی ایف رپورٹ بناوِو تہٕ سوزِو"
        )
    )

    fun get(key: String, lang: String): String {
        val map = translations[key] ?: return key
        return map[lang] ?: map["en"] ?: key
    }
}
