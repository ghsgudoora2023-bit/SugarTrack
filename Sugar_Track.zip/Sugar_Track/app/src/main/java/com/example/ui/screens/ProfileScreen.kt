package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.FamilyMemberEntity
import com.example.data.entity.UserProfileEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.StringsLocalizer
import com.example.viewmodel.SugarTrackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(viewModel: SugarTrackViewModel) {
    val context = LocalContext.current
    val profile by viewModel.userProfile.collectAsState()
    val familyMembers by viewModel.familyMembers.collectAsState()
    val isSenior by viewModel.isSeniorMode.collectAsState()
    val isDarkMode by viewModel.isDarkMode.collectAsState()
    val currentLang by viewModel.appLanguage.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val syncStatus by viewModel.syncStatusMessage.collectAsState()

    var showEditProfileDialog by remember { mutableStateOf(false) }
    var showAddFamilyDialog by remember { mutableStateOf(false) }
    var showPremiumDialog by remember { mutableStateOf(false) }
    var showPrivacyDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showReviewDialog by remember { mutableStateOf(false) }
    var showFaqDialog by remember { mutableStateOf(false) }
    var showAboutDialog by remember { mutableStateOf(false) }

    LaunchedEffect(syncStatus) {
        syncStatus?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
            viewModel.clearStatusMessage()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Patient Profile & Settings",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 22.sp else 19.sp,
                        color = MedicalBluePrimary
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 10.dp, bottom = 88.dp)
        ) {
            // 1. Patient Avatar & Primary Details Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(CircleShape)
                                        .background(MedicalBluePrimary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = profile?.name?.firstOrNull()?.uppercase() ?: "S",
                                        fontSize = 26.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.White
                                    )
                                }

                                Spacer(Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = profile?.name ?: "Sarah Jenkins",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = if (isSenior) 22.sp else 18.sp,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${profile?.diabetesType ?: "Type 2"} • ${profile?.age ?: 62} yrs",
                                        fontSize = if (isSenior) 14.sp else 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = "Height: ${profile?.heightCm?.toInt() ?: 165} cm | Weight: ${profile?.weightKg ?: 71.5} kg",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                            }

                            IconButton(
                                onClick = { showEditProfileDialog = true },
                                modifier = Modifier.testTag("edit_profile_button")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = MedicalBlueLight)
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = MaterialTheme.colorScheme.outlineVariant)

                        // Doctor & Emergency Details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Physician", fontSize = 11.sp, color = Color.Gray)
                                Text(profile?.doctorName ?: "Dr. Michael Chen, MD", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(profile?.doctorPhone ?: "+1 555-876-5432", fontSize = 11.sp, color = MedicalBlueLight)
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text("Emergency Contact", fontSize = 11.sp, color = Color.Gray)
                                Text(profile?.emergencyContactName ?: "David Jenkins", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(profile?.emergencyContactPhone ?: "+1 555-234-8901", fontSize = 11.sp, color = MedicalBlueLight)
                            }
                        }
                    }
                }
            }

            // 2. Premium Subscription Banner
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showPremiumDialog = true }
                        .testTag("premium_subscription_card"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPremium) Color(0xFFE8F5E9) else Color(0xFFFFF8E1)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                            Icon(
                                imageVector = if (isPremium) Icons.Default.Verified else Icons.Default.Stars,
                                contentDescription = null,
                                tint = if (isPremium) SugarNormalGreen else Color(0xFFF57F17),
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = if (isPremium) "SugarTrack Premium Active" else "SugarTrack Premium (₹99/year)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = if (isPremium) SugarNormalGreen else Color(0xFFBF360C)
                                )
                                Text(
                                    text = if (isPremium) "Cloud backup & unlimited family monitoring enabled" else "No ads, automatic cloud sync & unlimited PDF reports",
                                    fontSize = 11.sp,
                                    color = Color(0xFF5D4037)
                                )
                            }
                        }

                        if (!isPremium) {
                            Button(
                                onClick = { showPremiumDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF57F17)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text("Upgrade", fontSize = 12.sp, color = Color.White)
                            }
                        }
                    }
                }
            }

            // Health Consistency & Achievement Badges (Retention Strategy)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(24.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Consistency Badges & Streaks",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 18.sp else 15.sp
                            )
                        }

                        Spacer(Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Badge 1: 7 Days Logged
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFE8F5E9)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("🏅", fontSize = 20.sp)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("7 Days Logged", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Text("Unlocked ✓", fontSize = 10.sp, color = SugarNormalGreen)
                            }

                            // Badge 2: Medication Champion
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFE3F2FD)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("💊", fontSize = 20.sp)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("Med Champion", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Text("100% Adherence", fontSize = 10.sp, color = MedicalBluePrimary)
                            }

                            // Badge 3: 30 Days Logged
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFFFF3E0)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("🏆", fontSize = 20.sp)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("30 Days Logged", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Text("7/30 Days", fontSize = 10.sp, color = Color.Gray)
                            }

                            // Badge 4: 90 Days Consistent
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFF3E5F5)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("👑", fontSize = 20.sp)
                                }
                                Spacer(Modifier.height(4.dp))
                                Text("90 Days Master", fontSize = 11.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                                Text("Goal Ahead", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            // Share & Referral Strategy (WhatsApp & Social Growth)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Share, contentDescription = null, tint = MedicalBluePrimary, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                "Share SugarTrack with Family & Caregivers",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 17.sp else 15.sp
                            )
                        }

                        Spacer(Modifier.height(6.dp))

                        Text(
                            "Help friends, parents, or fellow diabetic patients track sugar levels and never miss medications.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(Modifier.height(12.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val sendIntent = android.content.Intent().apply {
                                        action = android.content.Intent.ACTION_SEND
                                        putExtra(android.content.Intent.EXTRA_TEXT, "I am managing my diabetes and medicines with SugarTrack: Track Sugar. Track Health! Download: https://sugartrack.app")
                                        type = "text/plain"
                                    }
                                    context.startActivity(android.content.Intent.createChooser(sendIntent, "Share SugarTrack via WhatsApp/SMS").apply {
                                        addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                    })
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Share App Link", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { showReviewDialog = true },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = MedicalBluePrimary),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Rate on Play Store", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // 3. Family Monitoring (Caregiver Access)
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FamilyRestroom, contentDescription = null, tint = MedicalBluePrimary)
                                Spacer(Modifier.width(8.dp))
                                Text("Family & Caregivers", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            TextButton(onClick = { showAddFamilyDialog = true }) {
                                Text("+ Add Member")
                            }
                        }

                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Caregivers receive instant phone/app alerts if sugar readings exceed critical thresholds or medicines are missed.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(Modifier.height(10.dp))

                        if (familyMembers.isEmpty()) {
                            Text("No family members linked yet.", fontSize = 12.sp, color = Color.Gray)
                        } else {
                            familyMembers.forEach { member ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("${member.name} (${member.relationship})", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                        Text("${member.phone} • Alerts ON", fontSize = 11.sp, color = SugarNormalGreen)
                                    }
                                    IconButton(onClick = { viewModel.deleteFamilyMember(member) }) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Remove", tint = Color.Gray, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Accessibility & Display Preferences
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Display & Accessibility", fontWeight = FontWeight.Bold, fontSize = 16.sp)

                        Spacer(Modifier.height(12.dp))

                        // Senior Mode Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Senior Mode (Elderly Friendly)", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text("Larger fonts, big action buttons, and high contrast", fontSize = 11.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = isSenior,
                                onCheckedChange = { viewModel.toggleSeniorMode(it) }
                            )
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

                        // Dark Mode Switch
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("Dark Theme", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                Text("Reduce eye strain in low-light environments", fontSize = 11.sp, color = Color.Gray)
                            }
                            Switch(
                                checked = isDarkMode,
                                onCheckedChange = { viewModel.toggleDarkMode(it) }
                            )
                        }

                        Divider(modifier = Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outlineVariant)

                        // Language Selection
                        Text("Language", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            StringsLocalizer.AppLanguage.values().forEach { lang ->
                                FilterChip(
                                    selected = currentLang == lang.code,
                                    onClick = { viewModel.setLanguage(lang.code) },
                                    label = { Text(lang.nativeName, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // Official Brand & About SugarTrack Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showAboutDialog = true }
                        .testTag("card_about_sugartrack"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            SugarTrackAppIconBadge(size = 52.dp)
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text(
                                    "About SugarTrack",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = if (isSenior) 18.sp else 16.sp
                                )
                                Text(
                                    "Track Sugar. Track Health.",
                                    fontSize = 12.sp,
                                    color = SugarTrackSlateText
                                )
                                Text(
                                    "Version 1.0 • Offline MVP",
                                    fontSize = 11.sp,
                                    color = SugarNormalGreen,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = "View Brand Identity",
                            tint = Color.Gray
                        )
                    }
                }
            }

            // 5. Cloud Backup & Data Security
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Cloud Backup & Security", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "All records are secured offline in your device's SQLite database. Sync with Firestore cloud for multi-device recovery.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(Modifier.height(14.dp))

                        Button(
                            onClick = { viewModel.syncCloudBackup() },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MedicalCyanSecondary)
                        ) {
                            Icon(Icons.Default.CloudSync, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Sync with Firestore Cloud")
                        }
                    }
                }
            }

            // 6. Help, FAQ & Support
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HelpOutline, contentDescription = null, tint = MedicalBluePrimary)
                                Spacer(Modifier.width(8.dp))
                                Text("Help & Support Center", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            }
                            TextButton(onClick = { showFaqDialog = true }) {
                                Text("View FAQ")
                            }
                        }

                        Spacer(Modifier.height(6.dp))

                        Text(
                            "Need clinical report assistance or account help? Contact our dedicated support team at:",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Email, contentDescription = null, tint = MedicalBlueLight, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("support@sugartrack.app", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MedicalBluePrimary)
                        }
                    }
                }
            }

            // 7. Play Store Compliance: Privacy Policy & Terms
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) {
                    TextButton(onClick = { showPrivacyDialog = true }) {
                        Text("Privacy Policy", fontSize = 12.sp)
                    }
                    Text("•", modifier = Modifier.align(Alignment.CenterVertically), color = Color.Gray)
                    TextButton(onClick = { showTermsDialog = true }) {
                        Text("Terms of Service", fontSize = 12.sp)
                    }
                }
            }
        }
    }

    // Edit Profile Dialog
    if (showEditProfileDialog) {
        EditProfileDialog(
            current = profile ?: UserProfileEntity(),
            onDismiss = { showEditProfileDialog = false },
            onSave = { updated ->
                viewModel.updateProfile(updated)
                showEditProfileDialog = false
            }
        )
    }

    // Add Family Member Dialog
    if (showAddFamilyDialog) {
        AddFamilyMemberDialog(
            onDismiss = { showAddFamilyDialog = false },
            onSave = { name, rel, phone, email ->
                viewModel.addFamilyMember(name, rel, phone, email)
                showAddFamilyDialog = false
            }
        )
    }

    // Premium Subscription Dialog
    if (showPremiumDialog) {
        PremiumSubscriptionDialog(
            onDismiss = { showPremiumDialog = false },
            onSubscribe = { planName ->
                viewModel.upgradeToPremium()
                showPremiumDialog = false
            }
        )
    }

    // Google Play Review Dialog (Review Strategy: Never immediate, shown after usage)
    if (showReviewDialog) {
        GooglePlayReviewDialog(
            onDismiss = { showReviewDialog = false },
            onSubmitRating = { stars, comment ->
                Toast.makeText(context, "Thank you for rating SugarTrack $stars stars!", Toast.LENGTH_SHORT).show()
                showReviewDialog = false
            }
        )
    }

    // Help & FAQ Dialog
    if (showFaqDialog) {
        FaqSupportDialog(onDismiss = { showFaqDialog = false })
    }

    // About SugarTrack Brand Dialog
    if (showAboutDialog) {
        AboutSugarTrackDialog(onDismiss = { showAboutDialog = false })
    }

    // Privacy Policy Dialog
    if (showPrivacyDialog) {
        AlertDialog(
            onDismissRequest = { showPrivacyDialog = false },
            title = { Text("Privacy Policy", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "SugarTrack is committed to protecting your sensitive medical telemetry.\n\n" +
                        "1. Local Storage First: Blood glucose readings, insulin doses, and personal health metrics reside on your device encrypted with Room.\n" +
                        "2. Cloud Sync: Optional Firebase Firestore cloud backup occurs only upon your explicit action.\n" +
                        "3. Zero Data Brokering: We never sell or share patient vitals with 3rd party advertising brokers.\n" +
                        "4. HIPAA / GDPR Compliance: You retain full rights to delete, export (via PDF), or wipe your health logs at any time.",
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showPrivacyDialog = false }) { Text("I Understand") } }
        )
    }

    // Terms Dialog
    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = { Text("Terms & Medical Disclaimer", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "SugarTrack is an informational personal tracking utility and is NOT a substitute for professional clinical diagnosis or physician counsel.\n\n" +
                        "Always consult your certified endocrinologist or primary healthcare physician before altering insulin dosages or medication regimens based on tracked telemetry.",
                        fontSize = 12.sp
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showTermsDialog = false }) { Text("Agree") } }
        )
    }
}

// Edit Profile Dialog
@Composable
fun EditProfileDialog(
    current: UserProfileEntity,
    onDismiss: () -> Unit,
    onSave: (UserProfileEntity) -> Unit
) {
    var name by remember { mutableStateOf(current.name) }
    var ageStr by remember { mutableStateOf(current.age.toString()) }
    var heightStr by remember { mutableStateOf(current.heightCm.toString()) }
    var weightStr by remember { mutableStateOf(current.weightKg.toString()) }
    var diabetesType by remember { mutableStateOf(current.diabetesType) }
    var emergencyName by remember { mutableStateOf(current.emergencyContactName) }
    var emergencyPhone by remember { mutableStateOf(current.emergencyContactPhone) }
    var doctorName by remember { mutableStateOf(current.doctorName) }
    var doctorPhone by remember { mutableStateOf(current.doctorPhone) }

    val types = listOf("Type 1", "Type 2", "Prediabetes")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Patient Profile", fontWeight = FontWeight.Bold) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                item {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = ageStr,
                            onValueChange = { ageStr = it },
                            label = { Text("Age") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = heightStr,
                            onValueChange = { heightStr = it },
                            label = { Text("Height (cm)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = weightStr,
                        onValueChange = { weightStr = it },
                        label = { Text("Weight (kg)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Text("Condition:", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        types.forEach { t ->
                            FilterChip(
                                selected = diabetesType == t,
                                onClick = { diabetesType = t },
                                label = { Text(t, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = doctorName,
                        onValueChange = { doctorName = it },
                        label = { Text("Doctor Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = doctorPhone,
                        onValueChange = { doctorPhone = it },
                        label = { Text("Doctor Phone") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = emergencyName,
                        onValueChange = { emergencyName = it },
                        label = { Text("Emergency Contact Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = emergencyPhone,
                        onValueChange = { emergencyPhone = it },
                        label = { Text("Emergency Contact Phone") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(
                    current.copy(
                        name = name,
                        age = ageStr.toIntOrNull() ?: current.age,
                        heightCm = heightStr.toDoubleOrNull() ?: current.heightCm,
                        weightKg = weightStr.toDoubleOrNull() ?: current.weightKg,
                        diabetesType = diabetesType,
                        doctorName = doctorName,
                        doctorPhone = doctorPhone,
                        emergencyContactName = emergencyName,
                        emergencyContactPhone = emergencyPhone
                    )
                )
            }) {
                Text("Save Profile")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// Add Family Member Dialog
@Composable
fun AddFamilyMemberDialog(
    onDismiss: () -> Unit,
    onSave: (name: String, rel: String, phone: String, email: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var rel by remember { mutableStateOf("Son / Daughter") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Family Member / Caregiver", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Name") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = rel,
                    onValueChange = { rel = it },
                    label = { Text("Relationship (e.g. Son, Spouse)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Phone Number") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email (Optional)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (name.isNotBlank()) onSave(name, rel, phone, email)
            }) {
                Text("Add Member")
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

// Premium Subscription Dialog
@Composable
fun PremiumSubscriptionDialog(
    onDismiss: () -> Unit,
    onSubscribe: (planName: String) -> Unit
) {
    var selectedPlan by remember { mutableStateOf("premium") } // "premium" or "unlimited"

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Stars, contentDescription = null, tint = Color(0xFFF57F17))
                Spacer(Modifier.width(8.dp))
                Text("Upgrade SugarTrack", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Select the subscription plan that fits your diabetes care needs:", fontSize = 13.sp)

                // Plan 1: Premium (₹99/year)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPlan = "premium" },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedPlan == "premium") Color(0xFFE8F5E9) else Color(0xFFF5F5F5)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Premium Plan", fontWeight = FontWeight.Bold, color = if (selectedPlan == "premium") SugarNormalGreen else Color.Black)
                            Text("₹99 / year", fontWeight = FontWeight.Bold, color = if (selectedPlan == "premium") SugarNormalGreen else Color.Black)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("• 100% Ad-Free & Offline First\n• Cloud Backup & Multi-device restore\n• Unlimited PDF Clinical Reports\n• Family Caregiver Alerts for missed doses", fontSize = 11.sp, color = Color.DarkGray)
                    }
                }

                // Plan 2: Unlimited (₹299/year)
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { selectedPlan = "unlimited" },
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedPlan == "unlimited") Color(0xFFE3F2FD) else Color(0xFFF5F5F5)
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Unlimited Plan", fontWeight = FontWeight.Bold, color = if (selectedPlan == "unlimited") MedicalBluePrimary else Color.Black)
                            Text("₹299 / year", fontWeight = FontWeight.Bold, color = if (selectedPlan == "unlimited") MedicalBluePrimary else Color.Black)
                        }
                        Spacer(Modifier.height(4.dp))
                        Text("• Everything in Premium\n• Direct Doctor Consultation Sharing\n• Advanced Trend Analytics & Projections\n• Priority Caregiver Support", fontSize = 11.sp, color = Color.DarkGray)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubscribe(selectedPlan) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF57F17))
            ) {
                Text(if (selectedPlan == "premium") "Start Premium Today (₹99/yr)" else "Start Unlimited Today (₹299/yr)")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Maybe Later") }
        }
    )
}

// Google Play Review Dialog (Polite Prompt Strategy)
@Composable
fun GooglePlayReviewDialog(
    onDismiss: () -> Unit,
    onSubmitRating: (stars: Int, comment: String) -> Unit
) {
    var rating by remember { mutableStateOf(5) }
    var reviewText by remember { mutableStateOf("SugarTrack has made tracking my daily insulin and glucose readings so easy!") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.RateReview, contentDescription = null, tint = MedicalBluePrimary)
                Spacer(Modifier.width(8.dp))
                Text("Enjoying SugarTrack?", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Your feedback helps us support more diabetic patients and families manage their health.",
                    fontSize = 13.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )

                // Star row
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    for (i in 1..5) {
                        IconButton(onClick = { rating = i }) {
                            Icon(
                                imageVector = if (i <= rating) Icons.Default.Star else Icons.Outlined.StarOutline,
                                contentDescription = "$i Stars",
                                tint = if (i <= rating) Color(0xFFFFB300) else Color.Gray,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = reviewText,
                    onValueChange = { reviewText = it },
                    label = { Text("What do you like most about SugarTrack?") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmitRating(rating, reviewText) },
                colors = ButtonDefaults.buttonColors(containerColor = MedicalBluePrimary)
            ) {
                Text("Submit Review")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Later") }
        }
    )
}

// Help, FAQ & Support Dialog
@Composable
fun FaqSupportDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HelpCenter, contentDescription = null, tint = MedicalBluePrimary)
                Spacer(Modifier.width(8.dp))
                Text("Help & Frequently Asked Questions", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("1. Medicine Reminders & Actionable Alarms", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MedicalBluePrimary)
                    Text("Reminders trigger local Android notifications with sound and vibration. Tap 'Mark Taken' directly from the notification shade to log your medication without opening the app.", fontSize = 12.sp, color = Color.DarkGray)
                }

                item {
                    Text("2. Blood Glucose Tracking & Target Ranges", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MedicalBluePrimary)
                    Text("Normal ADA target ranges are 70–130 mg/dL fasting, and < 180 mg/dL after meals. If your reading drops below 70 mg/dL, an immediate Hypoglycemia warning triggers.", fontSize = 12.sp, color = Color.DarkGray)
                }

                item {
                    Text("3. Subscriptions & Cancellation", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MedicalBluePrimary)
                    Text("The Premium plan is ₹99/year via Google Play Billing. You can cancel or restore your purchase at any time directly through the Google Play Store Subscriptions menu.", fontSize = 12.sp, color = Color.DarkGray)
                }

                item {
                    Text("4. Offline Storage & Cloud Sync", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MedicalBluePrimary)
                    Text("All your clinical records are stored locally and encrypted on your device. Authenticated users can tap 'Sync with Firestore Cloud' to enable multi-device recovery.", fontSize = 12.sp, color = Color.DarkGray)
                }

                item {
                    Text("5. Direct Medical Support", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MedicalBluePrimary)
                    Text("For technical assistance, email our dedicated clinical technology team at support@sugartrack.app.", fontSize = 12.sp, color = Color.DarkGray)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun AboutSugarTrackDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SugarTrackAppIconBadge(size = 40.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("SugarTrack", fontWeight = FontWeight.Black, fontSize = 20.sp)
                    Text("Official Brand Identity", fontSize = 11.sp, color = SugarTrackSlateText)
                }
            }
        },
        text = {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(SugarTrackBackgroundLight)
                            .padding(16.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        SugarTrackVerticalHeroLogo(iconSize = 72.dp)
                    }
                }

                item {
                    Text("Brand Color Palette", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Blue Brand
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(SugarTrackPrimaryBlue))
                            Spacer(Modifier.height(4.dp))
                            Text("#2563EB", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("Primary", fontSize = 9.sp, color = Color.Gray)
                        }
                        // Light Blue
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(SugarTrackLightBlue))
                            Spacer(Modifier.height(4.dp))
                            Text("#60A5FA", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("Secondary", fontSize = 9.sp, color = Color.Gray)
                        }
                        // Success Green
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(SugarTrackSuccessGreen))
                            Spacer(Modifier.height(4.dp))
                            Text("#22C55E", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("Success", fontSize = 9.sp, color = Color.Gray)
                        }
                        // Dark Navy
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Box(modifier = Modifier.size(36.dp).clip(CircleShape).background(SugarTrackDarkNavy))
                            Spacer(Modifier.height(4.dp))
                            Text("#0F172A", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("Charcoal", fontSize = 9.sp, color = Color.Gray)
                        }
                    }
                }

                item {
                    Divider(color = MaterialTheme.colorScheme.outlineVariant)
                    Spacer(Modifier.height(4.dp))
                    Text("Design Principles", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("• Modern & Minimal medical theme\n• High contrast & accessible 48dp+ touch targets\n• Elderly-friendly Senior Mode\n• 100% Offline-First (No internet required)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                item {
                    Text("MVP Core Capabilities", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("1. Medicine Reminders (Taken, Snooze, Missed)\n2. Blood Glucose Logging (Fasting, Meal, Random)\n3. Remaining Stock & Refill Alerts", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        },
        confirmButton = {
            Button(onClick = onDismiss, colors = ButtonDefaults.buttonColors(containerColor = SugarTrackPrimaryBlue)) {
                Text("Close")
            }
        }
    )
}
