package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.MedicineEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.util.StringsLocalizer
import com.example.viewmodel.SugarTrackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: SugarTrackViewModel,
    onNavigateToMedicines: () -> Unit,
    onNavigateToSugarLogs: () -> Unit,
    onNavigateToReports: () -> Unit
) {
    val context = LocalContext.current
    val profile by viewModel.userProfile.collectAsState()
    val medicines by viewModel.medicines.collectAsState()
    val lowStockMeds by viewModel.lowStockMedicines.collectAsState()
    val sugarLogs by viewModel.sugarLogs.collectAsState()
    val latestSugar by viewModel.latestSugarLog.collectAsState()
    val latestHba1c by viewModel.latestHbA1c.collectAsState()
    val appointments by viewModel.appointments.collectAsState()
    val isSenior by viewModel.isSeniorMode.collectAsState()
    val lang by viewModel.appLanguage.collectAsState()
    val isPremium by viewModel.isPremium.collectAsState()
    val waterGlasses by viewModel.waterGlasses.collectAsState()
    val dailySteps by viewModel.dailySteps.collectAsState()

    var selectedSlotType by remember { mutableStateOf("Fasting") }
    var showAddSugarDialog by remember { mutableStateOf(false) }
    var showEmergencyDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    SugarTrackPrimaryLogo(
                        iconSize = if (isSenior) 40.dp else 34.dp,
                        showTagline = true
                    )
                },
                actions = {
                    // Senior Mode Toggle Pill
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSenior) Color(0xFFFFD54F) else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { viewModel.toggleSeniorMode(!isSenior) }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                            .testTag("toggle_senior_mode")
                    ) {
                        Icon(
                            imageVector = if (isSenior) Icons.Default.AccessibilityNew else Icons.Outlined.Elderly,
                            contentDescription = "Senior Mode",
                            tint = if (isSenior) Color(0xFF3E2723) else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = if (isSenior) "Senior ON" else "Senior Mode",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSenior) Color(0xFF3E2723) else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(Modifier.width(4.dp))

                    // Emergency Doctor button
                    IconButton(
                        onClick = { showEmergencyDialog = true },
                        modifier = Modifier.testTag("emergency_doctor_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneInTalk,
                            contentDescription = "Call Doctor",
                            tint = SugarLowAlertRed
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddSugarDialog = true },
                containerColor = MedicalBluePrimary,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.WaterDrop, contentDescription = null) },
                text = {
                    Text(
                        StringsLocalizer.get("add_reading", lang),
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 17.sp else 14.sp
                    )
                },
                modifier = Modifier.testTag("fab_add_sugar")
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(top = 8.dp, bottom = 88.dp)
        ) {
            // 1. Welcome Patient Header & Condition Badge
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Hello, ${profile?.name ?: "Sarah"}",
                                style = if (isSenior) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MedicalBluePrimary)
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = profile?.diabetesType ?: "Type 2 Diabetes",
                                        color = Color.White,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    text = "Target: < 140 mg/dL",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.85f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Favorite,
                                contentDescription = null,
                                tint = SugarLowAlertRed,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                }
            }

            // Quick Action Buttons Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    QuickActionButton(
                        title = "Add Sugar",
                        icon = Icons.Default.WaterDrop,
                        tint = MedicalBluePrimary,
                        modifier = Modifier.weight(1f),
                        isSenior = isSenior,
                        onClick = {
                            selectedSlotType = "Fasting"
                            showAddSugarDialog = true
                        }
                    )
                    QuickActionButton(
                        title = "Add Med",
                        icon = Icons.Default.Medication,
                        tint = MedicalCyanSecondary,
                        modifier = Modifier.weight(1f),
                        isSenior = isSenior,
                        onClick = onNavigateToMedicines
                    )
                    QuickActionButton(
                        title = "Reports",
                        icon = Icons.Default.Assessment,
                        tint = MedicalBlueLight,
                        modifier = Modifier.weight(1f),
                        isSenior = isSenior,
                        onClick = onNavigateToReports
                    )
                    QuickActionButton(
                        title = "Emergency",
                        icon = Icons.Default.PhoneInTalk,
                        tint = SugarLowAlertRed,
                        modifier = Modifier.weight(1f),
                        isSenior = isSenior,
                        onClick = { showEmergencyDialog = true }
                    )
                }
            }

            // Health Summary Overview Card
            item {
                HealthSummaryCard(
                    avgGlucose = if (sugarLogs.isEmpty()) 118 else sugarLogs.map { it.value }.average().toInt(),
                    adherenceTaken = medicines.count { it.takenToday },
                    totalMeds = medicines.size,
                    hba1c = latestHba1c?.value ?: 6.7,
                    isSenior = isSenior
                )
            }

            // Today's 8 Sugar Schedule & Slot Readings Card
            item {
                TodaySugarSlotsCard(
                    sugarLogs = sugarLogs,
                    isSenior = isSenior,
                    onSlotClick = { slot ->
                        selectedSlotType = slot
                        showAddSugarDialog = true
                    }
                )
            }

            // 2. Refill Alerts Banner (if any medicine is <= 5 left)
            if (lowStockMeds.isNotEmpty()) {
                items(lowStockMeds) { med ->
                    RefillAlertCard(
                        medicineName = med.name,
                        stockLeft = med.quantityAvailable,
                        onRefillClick = { viewModel.refillMedicine(med, 30) }
                    )
                }
            }

            // 3. Today's Latest Sugar Reading Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateToSugarLogs() }
                        .testTag("card_latest_sugar"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Bloodtype,
                                    contentDescription = null,
                                    tint = MedicalBluePrimary
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    "Blood Glucose Status",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = if (isSenior) 18.sp else 15.sp
                                )
                            }

                            latestSugar?.let {
                                GlucoseStatusBadge(value = it.value, isSenior = isSenior)
                            }
                        }

                        Spacer(Modifier.height(12.dp))

                        if (latestSugar != null) {
                            Row(
                                verticalAlignment = Alignment.Bottom,
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = "${latestSugar!!.value.toInt()}",
                                        fontSize = if (isSenior) 48.sp else 38.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = when {
                                            latestSugar!!.value < 70 -> SugarLowAlertRed
                                            latestSugar!!.value <= 140 -> SugarNormalGreen
                                            else -> SugarHighAlertOrange
                                        }
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        text = "mg/dL",
                                        fontSize = if (isSenior) 18.sp else 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(bottom = 6.dp)
                                    )
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = "${latestSugar!!.readingType} • ${latestSugar!!.time}",
                                        fontSize = if (isSenior) 14.sp else 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = latestSugar!!.date,
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        } else {
                            Text(
                                "No readings recorded today. Tap '+' below to log your sugar.",
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(Modifier.height(14.dp))

                        // Mini Trend preview
                        Text(
                            text = StringsLocalizer.get("sugar_trend", lang) + " (Last 7 Days)",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(Modifier.height(6.dp))
                        GlucoseTrendChart(logs = sugarLogs.take(10), heightDp = if (isSenior) 160 else 130)
                    }
                }
            }

            // 4. Medicines Due Today Schedule
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Medication,
                                    contentDescription = null,
                                    tint = MedicalBluePrimary
                                )
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    StringsLocalizer.get("due_today", lang),
                                    fontWeight = FontWeight.Bold,
                                    fontSize = if (isSenior) 19.sp else 16.sp
                                )
                            }
                            TextButton(onClick = onNavigateToMedicines) {
                                Text("View All (${medicines.size})")
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        if (medicines.isEmpty()) {
                            Text("No medicines configured.", color = Color.Gray)
                        } else {
                            medicines.take(3).forEach { med ->
                                TodayMedicineItemRow(
                                    medicine = med,
                                    isSenior = isSenior,
                                    onTakenClick = { viewModel.markMedicineTaken(med) },
                                    onMissedClick = { viewModel.markMedicineMissed(med) },
                                    onTestNotification = { viewModel.testReminderNotification(med) }
                                )
                                Spacer(Modifier.height(10.dp))
                            }
                        }
                    }
                }
            }

            // 5. HbA1c Status & Upcoming Appointments Row
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // HbA1c Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToReports() },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Analytics, contentDescription = null, tint = MedicalCyanSecondary, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Recent HbA1c", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            Text(
                                text = if (latestHba1c != null) "${latestHba1c!!.value}%" else "6.7%",
                                fontSize = if (isSenior) 28.sp else 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MedicalCyanSecondary
                            )
                            Text(
                                text = "Target < 7.0% (Good)",
                                fontSize = 11.sp,
                                color = SugarNormalGreen,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    // Appointments Card
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onNavigateToReports() },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = MedicalBlueLight, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Appointment", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(Modifier.height(8.dp))
                            val nextAppt = appointments.firstOrNull()
                            if (nextAppt != null) {
                                Text(nextAppt.doctorName.take(15), fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1)
                                Text("${nextAppt.date} • ${nextAppt.time}", fontSize = 11.sp, color = Color.Gray)
                            } else {
                                Text("No pending visit", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }

            // Water Intake Tracker Card
            item {
                WaterIntakeCard(
                    glasses = waterGlasses,
                    isSenior = isSenior,
                    onAdd = { viewModel.incrementWater() },
                    onRemove = { viewModel.decrementWater() }
                )
            }

            // Daily Steps / Activity Preview Card
            item {
                DailyActivityCard(
                    steps = dailySteps,
                    targetSteps = 8000,
                    isSenior = isSenior,
                    onAddSteps = { viewModel.addSteps(500) }
                )
            }

            // 6. AdMob Banner (respectful, at bottom of scroll, never interrupting)
            item {
                AdMobBannerSimulation(isPremium = isPremium)
            }
        }
    }

    // Quick Add Sugar Dialog
    if (showAddSugarDialog) {
        AddSugarLogDialog(
            initialType = selectedSlotType,
            onDismiss = { showAddSugarDialog = false },
            onSave = { value, type, notes ->
                viewModel.addSugarReading(value, type, notes)
                showAddSugarDialog = false
            },
            isSenior = isSenior
        )
    }

    // Emergency Contacts Dialog
    if (showEmergencyDialog) {
        EmergencyCallDialog(
            doctorName = profile?.doctorName ?: "Dr. Michael Chen",
            doctorPhone = profile?.doctorPhone ?: "+15558765432",
            emergencyName = profile?.emergencyContactName ?: "David Jenkins",
            emergencyPhone = profile?.emergencyContactPhone ?: "+15552348901",
            onDismiss = { showEmergencyDialog = false }
        )
    }
}

@Composable
fun TodayMedicineItemRow(
    medicine: MedicineEntity,
    isSenior: Boolean,
    onTakenClick: () -> Unit,
    onMissedClick: () -> Unit,
    onTestNotification: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = when {
                medicine.takenToday -> Color(0xFFE8F5E9)
                medicine.missedToday -> Color(0xFFFFEBEE)
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
            }
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(if (isSenior) 40.dp else 32.dp)
                            .clip(CircleShape)
                            .background(MedicalBluePrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = when (medicine.category) {
                                "Insulin" -> Icons.Default.Vaccines
                                "Syrup" -> Icons.Default.LocalDrink
                                else -> Icons.Default.Medication
                            },
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(if (isSenior) 22.dp else 18.dp)
                        )
                    }

                    Spacer(Modifier.width(10.dp))

                    Column {
                        Text(
                            text = medicine.name,
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 18.sp else 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "${medicine.dosage} • ${medicine.reminderTime}",
                            fontSize = if (isSenior) 14.sp else 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Notification Bell icon to simulate alert
                IconButton(onClick = onTestNotification, modifier = Modifier.size(32.dp)) {
                    Icon(
                        Icons.Outlined.NotificationsActive,
                        contentDescription = "Test Reminder",
                        tint = MedicalBlueLight,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(Modifier.height(10.dp))

            // Action Buttons: Taken / Missed
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onTakenClick,
                    modifier = Modifier.weight(1f).height(if (isSenior) 48.dp else 38.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (medicine.takenToday) SugarNormalGreen else MedicalBluePrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        text = if (medicine.takenToday) "Taken ✓" else "Mark Taken",
                        fontSize = if (isSenior) 15.sp else 12.sp
                    )
                }

                OutlinedButton(
                    onClick = onMissedClick,
                    modifier = Modifier.weight(0.8f).height(if (isSenior) 48.dp else 38.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = if (medicine.missedToday) SugarLowAlertRed else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = if (medicine.missedToday) "Missed ✕" else "Missed",
                        fontSize = if (isSenior) 14.sp else 12.sp
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddSugarLogDialog(
    initialType: String = "Fasting",
    onDismiss: () -> Unit,
    onSave: (value: Double, type: String, notes: String) -> Unit,
    isSenior: Boolean
) {
    var valueStr by remember { mutableStateOf("115") }
    var selectedType by remember { mutableStateOf(initialType) }
    var notes by remember { mutableStateOf("") }

    val readingTypes = listOf(
        "Fasting",
        "Post Breakfast",
        "Pre Lunch",
        "Post Lunch",
        "Pre Dinner",
        "Post Dinner",
        "Bedtime",
        "Random"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Bloodtype, contentDescription = null, tint = MedicalBluePrimary)
                Spacer(Modifier.width(8.dp))
                Text("Log Blood Sugar", fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                // Value Input
                OutlinedTextField(
                    value = valueStr,
                    onValueChange = { valueStr = it },
                    label = { Text("Blood Glucose (mg/dL)") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("input_sugar_value"),
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = { Text("mg/dL", modifier = Modifier.padding(end = 12.dp), color = Color.Gray) }
                )

                // Reading Type selector
                Text("Reading Time / Meal Slot:", style = MaterialTheme.typography.labelMedium)
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(readingTypes) { type ->
                        FilterChip(
                            selected = selectedType == type,
                            onClick = { selectedType = type },
                            label = { Text(type, fontSize = 11.sp) }
                        )
                    }
                }

                // Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (e.g. 2hr post breakfast)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val parsed = valueStr.toDoubleOrNull() ?: 110.0
                    onSave(parsed, selectedType, notes)
                },
                modifier = Modifier.testTag("save_sugar_button")
            ) {
                Text("Save Reading")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun QuickActionButton(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    isSenior: Boolean,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable { onClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp, horizontal = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(if (isSenior) 40.dp else 36.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = tint,
                    modifier = Modifier.size(if (isSenior) 22.dp else 19.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text(
                text = title,
                fontSize = if (isSenior) 13.sp else 11.sp,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1
            )
        }
    }
}

@Composable
fun HealthSummaryCard(
    avgGlucose: Int,
    adherenceTaken: Int,
    totalMeds: Int,
    hba1c: Double,
    isSenior: Boolean
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Health Summary",
                    fontWeight = FontWeight.Bold,
                    fontSize = if (isSenior) 18.sp else 15.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "Today's Status",
                    fontSize = 11.sp,
                    color = SugarNormalGreen,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Avg Glucose
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$avgGlucose",
                        fontSize = if (isSenior) 24.sp else 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (avgGlucose in 70..140) SugarNormalGreen else SugarHighAlertOrange
                    )
                    Text("Avg mg/dL", fontSize = 11.sp, color = Color.Gray)
                }

                // Divider
                Box(modifier = Modifier.width(1.dp).height(36.dp).background(Color.LightGray.copy(alpha = 0.5f)))

                // Adherence
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$adherenceTaken/$totalMeds",
                        fontSize = if (isSenior) 24.sp else 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MedicalBluePrimary
                    )
                    Text("Meds Taken", fontSize = 11.sp, color = Color.Gray)
                }

                // Divider
                Box(modifier = Modifier.width(1.dp).height(36.dp).background(Color.LightGray.copy(alpha = 0.5f)))

                // HbA1c
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        text = "$hba1c%",
                        fontSize = if (isSenior) 24.sp else 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = MedicalCyanSecondary
                    )
                    Text("HbA1c Target", fontSize = 11.sp, color = Color.Gray)
                }

                // Divider
                Box(modifier = Modifier.width(1.dp).height(36.dp).background(Color.LightGray.copy(alpha = 0.5f)))

                // Streak
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                    Text(
                        text = "14d",
                        fontSize = if (isSenior) 24.sp else 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFF57C00)
                    )
                    Text("Streak 🔥", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
    }
}

@Composable
fun TodaySugarSlotsCard(
    sugarLogs: List<com.example.data.entity.SugarLogEntity>,
    isSenior: Boolean,
    onSlotClick: (slotName: String) -> Unit
) {
    val slots = listOf(
        "Fasting",
        "Post Breakfast",
        "Pre Lunch",
        "Post Lunch",
        "Pre Dinner",
        "Post Dinner",
        "Bedtime",
        "Random"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = MedicalBluePrimary, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "Today's Sugar Schedule",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 17.sp else 14.sp
                    )
                }
                Text("Tap slot to log", fontSize = 11.sp, color = Color.Gray)
            }
            Spacer(Modifier.height(10.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(slots) { slot ->
                    val matchingLog = sugarLogs.firstOrNull { it.readingType.equals(slot, ignoreCase = true) }
                    Card(
                        modifier = Modifier
                            .width(if (isSenior) 110.dp else 95.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSlotClick(slot) },
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (matchingLog != null)
                                MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                            else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(
                            modifier = Modifier.padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = slot,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(Modifier.height(6.dp))
                            if (matchingLog != null) {
                                Text(
                                    text = "${matchingLog.value.toInt()}",
                                    fontSize = if (isSenior) 18.sp else 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when {
                                        matchingLog.value < 70 -> SugarLowAlertRed
                                        matchingLog.value <= 140 -> SugarNormalGreen
                                        else -> SugarHighAlertOrange
                                    }
                                )
                                Text("mg/dL", fontSize = 9.sp, color = Color.Gray)
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(MedicalBluePrimary.copy(alpha = 0.1f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.Add,
                                        contentDescription = "Log $slot",
                                        tint = MedicalBluePrimary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                                Text("Record", fontSize = 9.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun WaterIntakeCard(
    glasses: Int,
    isSenior: Boolean,
    onAdd: () -> Unit,
    onRemove: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocalDrink, contentDescription = null, tint = Color(0xFF0288D1), modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Hydration & Water Intake",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 18.sp else 15.sp
                    )
                }
                Text(
                    text = "$glasses / 8 Glasses (${glasses * 250} ml)",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0288D1)
                )
            }

            Spacer(Modifier.height(8.dp))

            // Progress Bar
            val progress = (glasses / 8f).coerceIn(0f, 1f)
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = Color(0xFF0288D1),
                trackColor = Color(0xFFE1F5FE)
            )

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (glasses >= 8) "🎉 Daily target completed!" else "Keep hydrated to help kidney function",
                    fontSize = 11.sp,
                    color = if (glasses >= 8) SugarNormalGreen else Color.Gray
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedIconButton(
                        onClick = onRemove,
                        modifier = Modifier.size(34.dp),
                        enabled = glasses > 0
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease water", modifier = Modifier.size(16.dp))
                    }
                    IconButton(
                        onClick = onAdd,
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF0288D1))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add glass", tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun DailyActivityCard(
    steps: Int,
    targetSteps: Int,
    isSenior: Boolean,
    onAddSteps: () -> Unit
) {
    val progress = (steps.toFloat() / targetSteps).coerceIn(0f, 1f)
    val calories = (steps * 0.04).toInt()
    val distanceKm = String.format(java.util.Locale.US, "%.1f", steps * 0.00075)
    val activeMinutes = (steps / 110)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsWalk, contentDescription = null, tint = MedicalBlueLight, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "Daily Activity & Steps",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 18.sp else 15.sp
                    )
                }

                OutlinedButton(
                    onClick = onAddSteps,
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                    modifier = Modifier.height(28.dp)
                ) {
                    Text("+500 Walk", fontSize = 11.sp)
                }
            }

            Spacer(Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = String.format(java.util.Locale.US, "%,d", steps),
                            fontSize = if (isSenior) 26.sp else 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = MedicalBluePrimary
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = "/ ${String.format(java.util.Locale.US, "%,d", targetSteps)} steps",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }
                }
                Text(
                    text = "${(progress * 100).toInt()}%",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = MedicalBluePrimary
                )
            }

            Spacer(Modifier.height(6.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = MedicalBluePrimary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("🔥 $calories kcal", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("📍 $distanceKm km", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("⏱️ $activeMinutes mins active", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
