package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.*
import com.example.data.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

@Database(
    entities = [
        MedicineEntity::class,
        SugarLogEntity::class,
        HbA1cEntity::class,
        BloodPressureEntity::class,
        WeightEntity::class,
        AppointmentEntity::class,
        PrescriptionEntity::class,
        FamilyMemberEntity::class,
        UserProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SugarTrackDatabase : RoomDatabase() {
    abstract fun medicineDao(): MedicineDao
    abstract fun sugarLogDao(): SugarLogDao
    abstract fun hba1cDao(): HbA1cDao
    abstract fun bloodPressureDao(): BloodPressureDao
    abstract fun weightDao(): WeightDao
    abstract fun appointmentDao(): AppointmentDao
    abstract fun prescriptionDao(): PrescriptionDao
    abstract fun familyDao(): FamilyDao
    abstract fun profileDao(): ProfileDao

    companion object {
        @Volatile
        private var INSTANCE: SugarTrackDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope = CoroutineScope(Dispatchers.IO)): SugarTrackDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SugarTrackDatabase::class.java,
                    "sugartrack_database"
                )
                    .addCallback(DatabaseCallback(scope))
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(database: SugarTrackDatabase) {
                val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val today = sdfDate.format(Date())
                val now = System.currentTimeMillis()
                val oneDay = 86_400_000L

                // 1. Initial User Profile
                database.profileDao().saveProfile(
                    UserProfileEntity(
                        id = 1,
                        name = "Sarah Jenkins",
                        email = "sarah.j@example.com",
                        age = 62,
                        gender = "Female",
                        heightCm = 165.0,
                        weightKg = 71.5,
                        diabetesType = "Type 2",
                        emergencyContactName = "David Jenkins (Son)",
                        emergencyContactPhone = "+1 (555) 234-8901",
                        doctorName = "Dr. Michael Chen, MD (Endocrinology)",
                        doctorPhone = "+1 (555) 876-5432",
                        isSeniorMode = false,
                        languageCode = "en",
                        isPremium = false,
                        isDarkMode = false,
                        notificationsEnabled = true
                    )
                )

                // 2. Initial Medicines
                database.medicineDao().insertMedicine(
                    MedicineEntity(
                        name = "Metformin HCl",
                        dosage = "500 mg",
                        frequency = "Twice Daily (Morning & Night)",
                        quantityAvailable = 4, // Trigger refill alert (< 5)
                        reminderTime = "08:00 AM",
                        reminderHour = 8,
                        reminderMinute = 0,
                        startDate = today,
                        notes = "Take with or immediately after food to avoid stomach upset.",
                        category = "Tablet",
                        takenToday = true,
                        missedToday = false,
                        lastTakenTimestamp = now - 3600000,
                        refillThreshold = 5
                    )
                )

                database.medicineDao().insertMedicine(
                    MedicineEntity(
                        name = "Glimepiride",
                        dosage = "2 mg",
                        frequency = "Once Daily (Morning)",
                        quantityAvailable = 18,
                        reminderTime = "08:30 AM",
                        reminderHour = 8,
                        reminderMinute = 30,
                        startDate = today,
                        notes = "Take 15 minutes before breakfast.",
                        category = "Tablet",
                        takenToday = false,
                        missedToday = false
                    )
                )

                database.medicineDao().insertMedicine(
                    MedicineEntity(
                        name = "Lantus Insulin Glargine",
                        dosage = "14 Units",
                        frequency = "Once Daily (Bedtime)",
                        quantityAvailable = 2, // Low stock alert
                        reminderTime = "09:30 PM",
                        reminderHour = 21,
                        reminderMinute = 30,
                        startDate = today,
                        notes = "Subcutaneous injection into abdomen or thigh. Rotate sites.",
                        category = "Insulin",
                        takenToday = false,
                        missedToday = false,
                        refillThreshold = 3
                    )
                )

                database.medicineDao().insertMedicine(
                    MedicineEntity(
                        name = "Vitamin D3",
                        dosage = "1000 IU",
                        frequency = "Once Daily (Afternoon)",
                        quantityAvailable = 35,
                        reminderTime = "01:00 PM",
                        reminderHour = 13,
                        reminderMinute = 0,
                        startDate = today,
                        notes = "Take with lunch.",
                        category = "Tablet",
                        takenToday = false,
                        missedToday = false
                    )
                )

                // 3. Sugar Logs for past 7 days to populate trend charts instantly
                val readings = listOf(
                    Triple(105.0, "Fasting", 0L),
                    Triple(142.0, "After Meal", 0L),
                    Triple(118.0, "Before Meal", 1L),
                    Triple(155.0, "After Meal", 1L),
                    Triple(98.0, "Fasting", 2L),
                    Triple(135.0, "After Meal", 2L),
                    Triple(112.0, "Fasting", 3L),
                    Triple(168.0, "After Meal", 3L),
                    Triple(104.0, "Fasting", 4L),
                    Triple(140.0, "After Meal", 4L),
                    Triple(110.0, "Fasting", 5L),
                    Triple(149.0, "After Meal", 5L),
                    Triple(108.0, "Fasting", 6L)
                )

                for ((value, type, daysAgo) in readings) {
                    val logDate = sdfDate.format(Date(now - daysAgo * oneDay))
                    database.sugarLogDao().insertLog(
                        SugarLogEntity(
                            value = value,
                            readingType = type,
                            date = logDate,
                            time = if (type == "Fasting") "07:30 AM" else "02:15 PM",
                            notes = if (type == "After Meal") "Post-lunch 2hr reading" else "Morning fasting check",
                            timestamp = now - daysAgo * oneDay
                        )
                    )
                }

                // 4. HbA1c Records
                database.hba1cDao().insertRecord(
                    HbA1cEntity(
                        value = 6.7,
                        testDate = sdfDate.format(Date(now - 14 * oneDay)),
                        labName = "City Health Diagnostics",
                        notes = "Target < 7.0% met! Stable control over past quarter.",
                        timestamp = now - 14 * oneDay
                    )
                )
                database.hba1cDao().insertRecord(
                    HbA1cEntity(
                        value = 7.3,
                        testDate = sdfDate.format(Date(now - 105 * oneDay)),
                        labName = "Metropolis Labs",
                        notes = "Slightly elevated, dosage adjusted.",
                        timestamp = now - 105 * oneDay
                    )
                )

                // 5. Blood Pressure Record
                database.bloodPressureDao().insertRecord(
                    BloodPressureEntity(
                        systolic = 122,
                        diastolic = 78,
                        pulse = 72,
                        date = today,
                        time = "08:15 AM",
                        notes = "Resting sitting position. Normal BP."
                    )
                )

                // 6. Weight Record
                database.weightDao().insertRecord(
                    WeightEntity(
                        weightKg = 71.5,
                        date = today,
                        notes = "Morning weight before breakfast."
                    )
                )

                // 7. Upcoming Appointment
                database.appointmentDao().insertAppointment(
                    AppointmentEntity(
                        doctorName = "Dr. Michael Chen, MD",
                        hospital = "Metropolitan Endocrinology & Diabetes Center",
                        date = sdfDate.format(Date(now + 3 * oneDay)),
                        time = "10:30 AM",
                        notes = "Quarterly comprehensive diabetes review & kidney panel test."
                    )
                )

                // 8. Family Member
                database.familyDao().insertMember(
                    FamilyMemberEntity(
                        name = "David Jenkins",
                        relationship = "Son / Primary Caregiver",
                        phone = "+1 (555) 234-8901",
                        email = "david.jenkins@example.com",
                        alertOnMissedMedicine = true,
                        alertOnAbnormalSugar = true
                    )
                )
            }
        }
    }
}
