package com.example.util

import android.util.Log

object AnalyticsTracker {

    private const val TAG = "SugarTrackAnalytics"

    fun logEvent(eventName: String, params: Map<String, Any> = emptyMap()) {
        val paramString = if (params.isNotEmpty()) " with params: $params" else ""
        Log.i(TAG, "Event logged: [$eventName]$paramString")
    }

    // Specific SAS events
    fun logAppOpen() = logEvent("app_open")
    fun logAddMedicine(name: String, category: String) = logEvent("add_medicine", mapOf("name" to name, "category" to category))
    fun logSugar(value: Double, type: String) = logEvent("log_sugar", mapOf("value" to value, "type" to type))
    fun logUploadPrescription(doctor: String) = logEvent("upload_prescription", mapOf("doctor" to doctor))
    fun logGenerateReport() = logEvent("generate_report")
    fun logPremiumPurchase() = logEvent("premium_purchase", mapOf("plan" to "annual_99_inr"))
    fun logNotificationTaken(medicine: String) = logEvent("notification_taken", mapOf("medicine" to medicine))
    fun logNotificationMissed(medicine: String) = logEvent("notification_missed", mapOf("medicine" to medicine))
}
