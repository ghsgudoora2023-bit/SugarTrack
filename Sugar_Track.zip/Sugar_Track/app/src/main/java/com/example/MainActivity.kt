package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.*
import com.example.ui.screens.*
import com.example.ui.theme.MedicalBluePrimary
import com.example.ui.theme.SugarTrackTheme
import com.example.util.StringsLocalizer
import com.example.viewmodel.SugarTrackViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: SugarTrackViewModel = viewModel()
            val isDarkMode by viewModel.isDarkMode.collectAsState()

            SugarTrackTheme(darkTheme = isDarkMode) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    var showSplash by remember { mutableStateOf(true) }

                    LaunchedEffect(Unit) {
                        kotlinx.coroutines.delay(1600)
                        showSplash = false
                    }

                    if (showSplash) {
                        SplashScreen()
                    } else {
                        val isLoggedIn by viewModel.isLoggedIn.collectAsState()

                        if (!isLoggedIn) {
                            AuthScreen(viewModel = viewModel)
                        } else {
                            MainAppContent(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SplashScreen() {
    val alphaAnim = rememberInfiniteTransition(label = "pulse")
    val alpha by alphaAnim.animateFloat(
        initialValue = 0.88f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface),
        contentAlignment = Alignment.Center
    ) {
        Box(modifier = Modifier.alpha(alpha)) {
            SugarTrackVerticalHeroLogo(iconSize = 96.dp)
        }
    }
}

@Composable
fun MainAppContent(viewModel: SugarTrackViewModel) {
    val currentNavIndex by viewModel.currentNavIndex.collectAsState()
    val isSenior by viewModel.isSeniorMode.collectAsState()
    val lang by viewModel.appLanguage.collectAsState()

    // Back handler: Return to Home if on another tab
    BackHandler(enabled = currentNavIndex != 0) {
        viewModel.setNavIndex(0)
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp,
                modifier = Modifier.testTag("bottom_navigation_bar")
            ) {
                // 1. Home
                NavigationBarItem(
                    selected = currentNavIndex == 0,
                    onClick = { viewModel.setNavIndex(0) },
                    icon = {
                        Icon(
                            if (currentNavIndex == 0) Icons.Filled.Home else Icons.Outlined.Home,
                            contentDescription = "Home"
                        )
                    },
                    label = {
                        Text(
                            StringsLocalizer.get("nav_home", lang),
                            fontSize = if (isSenior) 13.sp else 11.sp,
                            fontWeight = if (currentNavIndex == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MedicalBluePrimary
                    ),
                    modifier = Modifier.testTag("nav_item_home")
                )

                // 2. Medicines
                NavigationBarItem(
                    selected = currentNavIndex == 1,
                    onClick = { viewModel.setNavIndex(1) },
                    icon = {
                        Icon(
                            if (currentNavIndex == 1) Icons.Filled.Medication else Icons.Outlined.Medication,
                            contentDescription = "Medicines"
                        )
                    },
                    label = {
                        Text(
                            StringsLocalizer.get("nav_medicines", lang),
                            fontSize = if (isSenior) 13.sp else 11.sp,
                            fontWeight = if (currentNavIndex == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MedicalBluePrimary
                    ),
                    modifier = Modifier.testTag("nav_item_medicines")
                )

                // 3. Sugar Logs
                NavigationBarItem(
                    selected = currentNavIndex == 2,
                    onClick = { viewModel.setNavIndex(2) },
                    icon = {
                        Icon(
                            if (currentNavIndex == 2) Icons.Filled.WaterDrop else Icons.Outlined.WaterDrop,
                            contentDescription = "Sugar Logs"
                        )
                    },
                    label = {
                        Text(
                            StringsLocalizer.get("nav_sugar_logs", lang),
                            fontSize = if (isSenior) 13.sp else 11.sp,
                            fontWeight = if (currentNavIndex == 2) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MedicalBluePrimary
                    ),
                    modifier = Modifier.testTag("nav_item_sugar_logs")
                )

                // 4. Reports
                NavigationBarItem(
                    selected = currentNavIndex == 3,
                    onClick = { viewModel.setNavIndex(3) },
                    icon = {
                        Icon(
                            if (currentNavIndex == 3) Icons.Filled.Assessment else Icons.Outlined.Assessment,
                            contentDescription = "Reports"
                        )
                    },
                    label = {
                        Text(
                            StringsLocalizer.get("nav_reports", lang),
                            fontSize = if (isSenior) 13.sp else 11.sp,
                            fontWeight = if (currentNavIndex == 3) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MedicalBluePrimary
                    ),
                    modifier = Modifier.testTag("nav_item_reports")
                )

                // 5. Profile
                NavigationBarItem(
                    selected = currentNavIndex == 4,
                    onClick = { viewModel.setNavIndex(4) },
                    icon = {
                        Icon(
                            if (currentNavIndex == 4) Icons.Filled.Person else Icons.Outlined.Person,
                            contentDescription = "Profile"
                        )
                    },
                    label = {
                        Text(
                            StringsLocalizer.get("nav_profile", lang),
                            fontSize = if (isSenior) 13.sp else 11.sp,
                            fontWeight = if (currentNavIndex == 4) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                        selectedIconColor = MedicalBluePrimary
                    ),
                    modifier = Modifier.testTag("nav_item_profile")
                )
            }
        }
    ) { contentPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(contentPadding)
        ) {
            Crossfade(targetState = currentNavIndex, label = "screen_transition") { screen ->
                when (screen) {
                    0 -> HomeScreen(
                        viewModel = viewModel,
                        onNavigateToMedicines = { viewModel.setNavIndex(1) },
                        onNavigateToSugarLogs = { viewModel.setNavIndex(2) },
                        onNavigateToReports = { viewModel.setNavIndex(3) }
                    )
                    1 -> MedicinesScreen(viewModel = viewModel)
                    2 -> SugarLogsScreen(viewModel = viewModel)
                    3 -> ReportsScreen(viewModel = viewModel)
                    4 -> ProfileScreen(viewModel = viewModel)
                }
            }
        }
    }
}
