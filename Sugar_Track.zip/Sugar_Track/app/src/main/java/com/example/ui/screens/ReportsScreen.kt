package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.entity.*
import com.example.ui.theme.*
import com.example.viewmodel.SugarTrackViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: SugarTrackViewModel) {
    val context = LocalContext.current
    val isSenior by viewModel.isSeniorMode.collectAsState()

    val hba1cRecords by viewModel.hba1cRecords.collectAsState()
    val bpRecords by viewModel.bloodPressureRecords.collectAsState()
    val weightRecords by viewModel.weightRecords.collectAsState()
    val appointments by viewModel.appointments.collectAsState()
    val prescriptions by viewModel.prescriptions.collectAsState()
    val profile by viewModel.userProfile.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("PDF Report", "HbA1c", "BP Tracker", "Weight", "Visits", "Prescriptions", "Diet & Insights")

    // Dialog state holders
    var showAddHbA1cDialog by remember { mutableStateOf(false) }
    var showAddBpDialog by remember { mutableStateOf(false) }
    var showAddWeightDialog by remember { mutableStateOf(false) }
    var showAddApptDialog by remember { mutableStateOf(false) }
    var showAddPrescriptionDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Reports & Health Vitals",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 22.sp else 19.sp,
                        color = MedicalBluePrimary
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            // Scrollable Tab Row
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                edgePadding = 16.dp,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MedicalBluePrimary
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = if (isSenior) 14.sp else 12.sp
                            )
                        }
                    )
                }
            }

            Spacer(Modifier.height(8.dp))

            when (selectedTab) {
                0 -> PdfReportTab(
                    viewModel = viewModel,
                    isSenior = isSenior,
                    onGeneratePdf = {
                        val file = viewModel.generatePdfReport()
                        if (file != null) {
                            Toast.makeText(context, "PDF Report generated and ready to share!", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(context, "Failed to generate report", Toast.LENGTH_SHORT).show()
                        }
                    }
                )
                1 -> HbA1cTab(
                    records = hba1cRecords,
                    isSenior = isSenior,
                    onAddClick = { showAddHbA1cDialog = true },
                    onDelete = { viewModel.deleteHbA1c(it) }
                )
                2 -> BloodPressureTab(
                    records = bpRecords,
                    isSenior = isSenior,
                    onAddClick = { showAddBpDialog = true },
                    onDelete = { viewModel.deleteBloodPressure(it) }
                )
                3 -> WeightTab(
                    records = weightRecords,
                    heightCm = profile?.heightCm ?: 170.0,
                    isSenior = isSenior,
                    onAddClick = { showAddWeightDialog = true },
                    onDelete = { viewModel.deleteWeight(it) }
                )
                4 -> AppointmentsTab(
                    appointments = appointments,
                    isSenior = isSenior,
                    onAddClick = { showAddApptDialog = true },
                    onDelete = { viewModel.deleteAppointment(it) },
                    onTestReminder = { viewModel.testAppointmentNotification(it) }
                )
                5 -> PrescriptionVaultTab(
                    prescriptions = prescriptions,
                    isSenior = isSenior,
                    onAddClick = { showAddPrescriptionDialog = true },
                    onDelete = { viewModel.deletePrescription(it) }
                )
                6 -> DietAndInsightsTab(
                    viewModel = viewModel,
                    isSenior = isSenior
                )
            }
        }
    }

    // Add HbA1c Dialog
    if (showAddHbA1cDialog) {
        AddHbA1cDialog(
            onDismiss = { showAddHbA1cDialog = false },
            onSave = { v, d, l, n ->
                viewModel.addHbA1c(v, d, l, n)
                showAddHbA1cDialog = false
            }
        )
    }

    // Add BP Dialog
    if (showAddBpDialog) {
        AddBloodPressureDialog(
            onDismiss = { showAddBpDialog = false },
            onSave = { s, d, p, n ->
                viewModel.addBloodPressure(s, d, p, n)
                showAddBpDialog = false
            }
        )
    }

    // Add Weight Dialog
    if (showAddWeightDialog) {
        AddWeightDialog(
            onDismiss = { showAddWeightDialog = false },
            onSave = { w, n ->
                viewModel.addWeight(w, n)
                showAddWeightDialog = false
            }
        )
    }

    // Add Appointment Dialog
    if (showAddApptDialog) {
        AddAppointmentDialog(
            onDismiss = { showAddApptDialog = false },
            onSave = { doc, hosp, date, time, notes ->
                viewModel.addAppointment(doc, hosp, date, time, notes)
                showAddApptDialog = false
            }
        )
    }

    // Add Prescription Dialog
    if (showAddPrescriptionDialog) {
        AddPrescriptionDialog(
            onDismiss = { showAddPrescriptionDialog = false },
            onSave = { doc, date, notes, uri ->
                viewModel.addPrescription(doc, date, notes, uri)
                showAddPrescriptionDialog = false
            }
        )
    }
}

// 1. PDF Export Tab
@Composable
fun PdfReportTab(
    viewModel: SugarTrackViewModel,
    isSenior: Boolean,
    onGeneratePdf: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.PictureAsPdf,
                            contentDescription = null,
                            tint = SugarLowAlertRed,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(Modifier.width(12.dp))
                        Column {
                            Text(
                                "Doctor Consultation PDF",
                                fontWeight = FontWeight.Bold,
                                fontSize = if (isSenior) 20.sp else 17.sp
                            )
                            Text(
                                "Comprehensive health summary for your physician",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    Text(
                        "The generated PDF report compiles your complete clinical history including:",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(Modifier.height(8.dp))

                    val items = listOf(
                        "• Blood Glucose readings & glycemic control patterns",
                        "• Recent HbA1c test results with lab reference",
                        "• Active daily medicines, insulin regimen & dosages",
                        "• Resting blood pressure & pulse telemetry",
                        "• Patient profile, emergency info & doctor signature block"
                    )
                    items.forEach { bullet ->
                        Text(bullet, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurface, modifier = Modifier.padding(vertical = 2.dp))
                    }

                    Spacer(Modifier.height(18.dp))

                    Button(
                        onClick = onGeneratePdf,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("generate_pdf_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = MedicalBluePrimary)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null)
                        Spacer(Modifier.width(10.dp))
                        Text(
                            "Generate & Share PDF Report",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 15.sp
                        )
                    }
                }
            }
        }
    }
}

// 2. HbA1c Tab
@Composable
fun HbA1cTab(
    records: List<HbA1cEntity>,
    isSenior: Boolean,
    onAddClick: () -> Unit,
    onDelete: (HbA1cEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("ADA Guidelines for HbA1c", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "• Normal: Below 5.7%\n• Prediabetes: 5.7% – 6.4%\n• Diabetes Target for Adults: Under 7.0%",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("HbA1c Records (${records.size})", fontWeight = FontWeight.Bold, fontSize = if (isSenior) 19.sp else 16.sp)
                Button(onClick = onAddClick, shape = RoundedCornerShape(8.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Add Test")
                }
            }
        }

        items(records, key = { it.id }) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(if (item.value < 7.0) SugarNormalGreenBg else SugarHighAlertOrangeBg),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${item.value}%",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = if (item.value < 7.0) SugarNormalGreen else SugarHighAlertOrange
                            )
                        }

                        Spacer(Modifier.width(12.dp))

                        Column {
                            val eagMgDl = (28.7 * item.value - 46.7).toInt()
                            val eagMmol = String.format(java.util.Locale.US, "%.1f", (28.7 * item.value - 46.7) / 18.0182)

                            Text(
                                text = if (item.value < 7.0) "Within Target (< 7.0%)" else "Elevated (> 7.0%)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text("Tested on: ${item.testDate}", fontSize = 12.sp, color = Color.Gray)
                            Text(
                                text = "eAG: $eagMgDl mg/dL ($eagMmol mmol/L)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MedicalBluePrimary
                            )
                            if (item.labName.isNotBlank()) {
                                Text("Lab: ${item.labName}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }

                    IconButton(onClick = { onDelete(item) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                    }
                }
            }
        }
    }
}

// 3. Blood Pressure Tab
@Composable
fun BloodPressureTab(
    records: List<BloodPressureEntity>,
    isSenior: Boolean,
    onAddClick: () -> Unit,
    onDelete: (BloodPressureEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Blood Pressure Logs (${records.size})", fontWeight = FontWeight.Bold, fontSize = if (isSenior) 19.sp else 16.sp)
                Button(onClick = onAddClick, shape = RoundedCornerShape(8.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Log BP")
                }
            }
        }

        items(records, key = { it.id }) { bp ->
            val isNormal = bp.systolic < 130 && bp.diastolic < 85
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "${bp.systolic}/${bp.diastolic}",
                                fontSize = if (isSenior) 26.sp else 22.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isNormal) SugarNormalGreen else SugarHighAlertOrange
                            )
                            Spacer(Modifier.width(6.dp))
                            Text("mmHg", fontSize = 12.sp, color = Color.Gray)

                            Spacer(Modifier.width(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Favorite, contentDescription = null, tint = SugarLowAlertRed, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(3.dp))
                                Text("${bp.pulse} bpm", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }

                        Text("${bp.date} • ${bp.time}", fontSize = 11.sp, color = Color.Gray)
                        if (bp.notes.isNotBlank()) {
                            Text(bp.notes, fontSize = 11.sp, color = Color.Gray, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        }
                    }

                    IconButton(onClick = { onDelete(bp) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                    }
                }
            }
        }
    }
}

// 4. Weight Tab
@Composable
fun WeightTab(
    records: List<WeightEntity>,
    heightCm: Double,
    isSenior: Boolean,
    onAddClick: () -> Unit,
    onDelete: (WeightEntity) -> Unit
) {
    val latestWeight = records.firstOrNull()?.weightKg ?: 70.0
    val heightM = (heightCm / 100.0).coerceAtLeast(1.0)
    val bmi = latestWeight / (heightM * heightM)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Current Weight", fontSize = 12.sp, color = Color.Gray)
                        Text(
                            "$latestWeight kg",
                            fontSize = if (isSenior) 30.sp else 26.sp,
                            fontWeight = FontWeight.Bold,
                            color = MedicalBluePrimary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Calculated BMI", fontSize = 12.sp, color = Color.Gray)
                        Text(
                            String.format("%.1f", bmi),
                            fontSize = if (isSenior) 26.sp else 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = when {
                                bmi < 18.5 -> Color(0xFF0288D1)
                                bmi < 25.0 -> SugarNormalGreen
                                else -> SugarHighAlertOrange
                            }
                        )
                        Text(
                            if (bmi < 25.0) "Healthy Range" else "Overweight",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Weight History (${records.size})", fontWeight = FontWeight.Bold, fontSize = if (isSenior) 19.sp else 16.sp)
                Button(onClick = onAddClick, shape = RoundedCornerShape(8.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Add Weight")
                }
            }
        }

        items(records, key = { it.id }) { w ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("${w.weightKg} kg", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("Logged: ${w.date}", fontSize = 12.sp, color = Color.Gray)
                    }
                    IconButton(onClick = { onDelete(w) }) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                    }
                }
            }
        }
    }
}

// 5. Appointments Tab
@Composable
fun AppointmentsTab(
    appointments: List<AppointmentEntity>,
    isSenior: Boolean,
    onAddClick: () -> Unit,
    onDelete: (AppointmentEntity) -> Unit,
    onTestReminder: (AppointmentEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Doctor Appointments (${appointments.size})", fontWeight = FontWeight.Bold, fontSize = if (isSenior) 19.sp else 16.sp)
                Button(onClick = onAddClick, shape = RoundedCornerShape(8.dp)) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Book Visit")
                }
            }
        }

        if (appointments.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Box(modifier = Modifier.fillMaxWidth().padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No upcoming appointments. Schedule one with your doctor.")
                    }
                }
            }
        } else {
            items(appointments, key = { it.id }) { appt ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(appt.doctorName, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(appt.hospital, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Event, contentDescription = null, modifier = Modifier.size(14.dp), tint = MedicalBlueLight)
                                Spacer(Modifier.width(4.dp))
                                Text("${appt.date} at ${appt.time}", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                            if (appt.notes.isNotBlank()) {
                                Text("Note: ${appt.notes}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }

                        Row {
                            IconButton(onClick = { onTestReminder(appt) }) {
                                Icon(Icons.Outlined.NotificationsActive, contentDescription = "Test Notification", tint = MedicalBlueLight)
                            }
                            IconButton(onClick = { onDelete(appt) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }
                    }
                }
            }
        }
    }
}

// 6. Prescription Vault Tab (supports photo picker zero-permission standard)
@Composable
fun PrescriptionVaultTab(
    prescriptions: List<PrescriptionEntity>,
    isSenior: Boolean,
    onAddClick: () -> Unit,
    onDelete: (PrescriptionEntity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Prescription Vault (${prescriptions.size})", fontWeight = FontWeight.Bold, fontSize = if (isSenior) 19.sp else 16.sp)
                Button(onClick = onAddClick, shape = RoundedCornerShape(8.dp)) {
                    Icon(Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("Add Rx")
                }
            }
        }

        if (prescriptions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.DocumentScanner, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.Gray)
                        Spacer(Modifier.height(8.dp))
                        Text("No prescriptions stored yet. Upload photos of prescriptions from your clinic or doctor.")
                    }
                }
            }
        } else {
            items(prescriptions, key = { it.id }) { rx ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Prescription by ${rx.doctorName}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("Date: ${rx.date}", fontSize = 12.sp, color = Color.Gray)
                            }
                            IconButton(onClick = { onDelete(rx) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = Color.Gray)
                            }
                        }

                        if (rx.notes.isNotBlank()) {
                            Spacer(Modifier.height(4.dp))
                            Text(rx.notes, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }

                        if (rx.imageUri.isNotBlank()) {
                            Spacer(Modifier.height(10.dp))
                            AsyncImage(
                                model = rx.imageUri,
                                contentDescription = "Prescription Photo",
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.LightGray),
                                contentScale = ContentScale.Crop
                            )
                        }
                    }
                }
            }
        }
    }
}

// Add HbA1c Dialog
@Composable
fun AddHbA1cDialog(
    onDismiss: () -> Unit,
    onSave: (value: Double, date: String, lab: String, notes: String) -> Unit
) {
    var valueStr by remember { mutableStateOf("6.7") }
    var labName by remember { mutableStateOf("City Diagnostic Lab") }
    var notes by remember { mutableStateOf("Normal fasting HbA1c check") }
    val today = remember {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add HbA1c Result", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = valueStr,
                    onValueChange = { valueStr = it },
                    label = { Text("HbA1c Level (%)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = labName,
                    onValueChange = { labName = it },
                    label = { Text("Laboratory Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes / Target") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val v = valueStr.toDoubleOrNull() ?: 6.5
                onSave(v, today, labName, notes)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// Add Blood Pressure Dialog
@Composable
fun AddBloodPressureDialog(
    onDismiss: () -> Unit,
    onSave: (systolic: Int, diastolic: Int, pulse: Int, notes: String) -> Unit
) {
    var sysStr by remember { mutableStateOf("120") }
    var diaStr by remember { mutableStateOf("80") }
    var pulseStr by remember { mutableStateOf("72") }
    var notes by remember { mutableStateOf("Resting sitting position") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Blood Pressure & Pulse", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = sysStr,
                        onValueChange = { sysStr = it },
                        label = { Text("Systolic") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = diaStr,
                        onValueChange = { diaStr = it },
                        label = { Text("Diastolic") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }

                OutlinedTextField(
                    value = pulseStr,
                    onValueChange = { pulseStr = it },
                    label = { Text("Pulse (BPM)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val s = sysStr.toIntOrNull() ?: 120
                val d = diaStr.toIntOrNull() ?: 80
                val p = pulseStr.toIntOrNull() ?: 72
                onSave(s, d, p, notes)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// Add Weight Dialog
@Composable
fun AddWeightDialog(
    onDismiss: () -> Unit,
    onSave: (weightKg: Double, notes: String) -> Unit
) {
    var weightStr by remember { mutableStateOf("71.5") }
    var notes by remember { mutableStateOf("Morning weight before breakfast") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Log Weight", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = weightStr,
                    onValueChange = { weightStr = it },
                    label = { Text("Weight (kg)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                val w = weightStr.toDoubleOrNull() ?: 70.0
                onSave(w, notes)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// Add Appointment Dialog
@Composable
fun AddAppointmentDialog(
    onDismiss: () -> Unit,
    onSave: (doc: String, hosp: String, date: String, time: String, notes: String) -> Unit
) {
    var docName by remember { mutableStateOf("Dr. Michael Chen, MD") }
    var hospital by remember { mutableStateOf("Metropolitan Endocrinology Clinic") }
    var date by remember { mutableStateOf("2026-10-18") }
    var time by remember { mutableStateOf("10:30 AM") }
    var notes by remember { mutableStateOf("Review 3-month sugar log & urine microalbumin") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Schedule Doctor Appointment", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = docName,
                    onValueChange = { docName = it },
                    label = { Text("Doctor Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = hospital,
                    onValueChange = { hospital = it },
                    label = { Text("Hospital / Clinic") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = date,
                        onValueChange = { date = it },
                        label = { Text("Date (YYYY-MM-DD)") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                    OutlinedTextField(
                        value = time,
                        onValueChange = { time = it },
                        label = { Text("Time") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Purpose / Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(docName, hospital, date, time, notes)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// Add Prescription Dialog with Android Photo Picker support
@Composable
fun AddPrescriptionDialog(
    onDismiss: () -> Unit,
    onSave: (doc: String, date: String, notes: String, uri: String) -> Unit
) {
    var docName by remember { mutableStateOf("Dr. Michael Chen") }
    var notes by remember { mutableStateOf("Metformin 500mg BD, Glimepiride 2mg OD") }
    var selectedImageUri by remember { mutableStateOf("") }
    val today = remember {
        java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
    }

    // Zero-permission modern Android Photo Picker
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedImageUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Prescription", fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = docName,
                    onValueChange = { docName = it },
                    label = { Text("Doctor Name") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Medicines & Dosage Notes") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                OutlinedButton(
                    onClick = {
                        photoPickerLauncher.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = null)
                    Spacer(Modifier.width(8.dp))
                    Text(if (selectedImageUri.isBlank()) "Select Prescription Photo" else "Photo Selected ✓")
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(docName, today, notes, selectedImageUri)
            }) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// 7. Diet & Smart Diabetic Insights Tab
@Composable
fun DietAndInsightsTab(
    viewModel: SugarTrackViewModel,
    isSenior: Boolean
) {
    val sugarLogs by viewModel.sugarLogs.collectAsState()
    val avgGlucose = remember(sugarLogs) {
        if (sugarLogs.isEmpty()) 115.0 else sugarLogs.map { it.value }.average()
    }
    val hypoCount = remember(sugarLogs) { sugarLogs.count { it.value < 70.0 } }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Smart Glucose Trend Prediction
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = MedicalBluePrimary, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Smart Glycemic Health Assessment",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 18.sp else 15.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }

                    Spacer(Modifier.height(10.dp))

                    Text(
                        text = when {
                            hypoCount > 0 -> "⚠️ Low Blood Sugar Risk Detected: You logged $hypoCount reading(s) below 70 mg/dL. Keep 15g fast-acting carbs nearby."
                            avgGlucose in 70.0..130.0 -> "✓ Glycemic Stability Excellent: Your average fasting/pre-meal levels are well within target ADA range (70–130 mg/dL)."
                            avgGlucose <= 160.0 -> "ℹ️ Moderate Postprandial Elevation: Average is ${avgGlucose.toInt()} mg/dL. Consider increasing dietary fiber with lunches."
                            else -> "⚠️ Elevated Average: Average is ${avgGlucose.toInt()} mg/dL. Schedule a consultation with your endocrinologist to review insulin/medication dosage."
                        },
                        fontSize = if (isSenior) 15.sp else 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        // Emergency Hypoglycemia Rule of 15
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Emergency, contentDescription = null, tint = SugarLowAlertRed, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            "Emergency Hypoglycemia Protocol (Rule of 15)",
                            fontWeight = FontWeight.Bold,
                            fontSize = if (isSenior) 17.sp else 14.sp,
                            color = SugarLowAlertRed
                        )
                    }

                    Spacer(Modifier.height(8.dp))

                    Text(
                        "If your blood glucose drops under 70 mg/dL:\n" +
                        "1. Eat or drink 15 grams of fast carbs (1/2 cup fruit juice, 3-4 glucose tablets, or 1 tablespoon honey).\n" +
                        "2. Wait 15 minutes and re-check blood sugar.\n" +
                        "3. Repeat if still under 70 mg/dL. If unconscious, call emergency.",
                        fontSize = if (isSenior) 14.sp else 12.sp,
                        color = Color(0xFF212121),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // Glycemic Index Diet Recommendations
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Diabetic Nutrition & Glycemic Index Guide",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 18.sp else 15.sp
                    )

                    Spacer(Modifier.height(10.dp))

                    // Green Category
                    Row(verticalAlignment = Alignment.Top) {
                        Text("🟢", fontSize = 16.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Recommended (Low GI < 55):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SugarNormalGreen)
                            Text("Oats, lentils, chickpeas, spinach, methi, walnuts, chia seeds, unsweetened Greek yogurt, berries.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Orange Category
                    Row(verticalAlignment = Alignment.Top) {
                        Text("🟡", fontSize = 16.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Consume in Moderation (Medium GI 56–69):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SugarHighAlertOrange)
                            Text("Brown rice, whole wheat roti/chapati, boiled sweet potatoes, papaya, apples, bananas.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Red Category
                    Row(verticalAlignment = Alignment.Top) {
                        Text("🔴", fontSize = 16.sp)
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("Foods to Limit (High GI ≥ 70):", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SugarLowAlertRed)
                            Text("White refined bread, sodas, packaged fruit juices, sweets/mithai, cornflakes, fried snacks.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }
        }

        // Daily Exercise & Insulin Safety Tips
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Physical Activity & Medication Tips",
                        fontWeight = FontWeight.Bold,
                        fontSize = if (isSenior) 17.sp else 14.sp
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "• A brisk 15-minute walk after meals significantly blunts post-lunch blood sugar spikes.\n" +
                        "• Rotate insulin injection sites (abdomen, thighs, upper arms) to avoid lipohypertrophy.\n" +
                        "• Keep yourself well hydrated with at least 8 glasses of water daily.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }
    }
}
