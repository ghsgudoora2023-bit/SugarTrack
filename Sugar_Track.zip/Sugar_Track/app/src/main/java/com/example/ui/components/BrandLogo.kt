package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

/**
 * Renders the official SugarTrack blood drop icon with integrated checkmark.
 * Uses exact geometric bezier curves matching the brand identity specification.
 */
@Composable
fun SugarTrackDropIcon(
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    dropColor: Color = SugarTrackPrimaryBlue,
    checkColor: Color = Color.White
) {
    Canvas(modifier = modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height

        // Blood drop path
        val dropPath = Path().apply {
            // Apex at top center
            moveTo(w * 0.5f, h * 0.08f)
            // Left curve
            cubicTo(
                w * 0.5f, h * 0.08f,
                w * 0.15f, h * 0.48f,
                w * 0.15f, h * 0.66f
            )
            // Bottom bulb
            cubicTo(
                w * 0.15f, h * 0.86f,
                w * 0.31f, h * 0.98f,
                w * 0.5f, h * 0.98f
            )
            cubicTo(
                w * 0.69f, h * 0.98f,
                w * 0.85f, h * 0.86f,
                w * 0.85f, h * 0.66f
            )
            // Right curve back to top
            cubicTo(
                w * 0.85f, h * 0.48f,
                w * 0.5f, h * 0.08f,
                w * 0.5f, h * 0.08f
            )
            close()
        }

        drawPath(path = dropPath, color = dropColor)

        // Integrated Checkmark
        val checkPath = Path().apply {
            moveTo(w * 0.35f, h * 0.66f)
            lineTo(w * 0.46f, h * 0.77f)
            lineTo(w * 0.68f, h * 0.51f)
        }

        drawPath(
            path = checkPath,
            color = checkColor,
            style = Stroke(
                width = w * 0.09f,
                cap = StrokeCap.Round,
                join = StrokeJoin.Round
            )
        )
    }
}

/**
 * App Icon Card: Rounded squircle in Primary Blue with white drop & blue checkmark.
 * Exactly matches "APP ICON (512x512) PLAY STORE READY" from Brand Guide.
 */
@Composable
fun SugarTrackAppIconBadge(
    modifier: Modifier = Modifier,
    size: Dp = 64.dp
) {
    val cornerRadius = size * 0.22f
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(SugarTrackPrimaryBlue),
        contentAlignment = Alignment.Center
    ) {
        SugarTrackDropIcon(
            size = size * 0.75f,
            dropColor = Color.White,
            checkColor = SugarTrackPrimaryBlue
        )
    }
}

/**
 * Horizontal Primary Brand Logo:
 * Icon + "SugarTrack" Wordmark + "Track Sugar. Track Health." Tagline.
 */
@Composable
fun SugarTrackPrimaryLogo(
    modifier: Modifier = Modifier,
    iconSize: Dp = 44.dp,
    showTagline: Boolean = true,
    isDark: Boolean = isSystemInDarkTheme()
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically
    ) {
        SugarTrackDropIcon(
            size = iconSize,
            dropColor = SugarTrackPrimaryBlue,
            checkColor = Color.White
        )

        Spacer(Modifier.width(12.dp))

        Column {
            Text(
                text = buildAnnotatedString {
                    withStyle(
                        SpanStyle(
                            color = if (isDark) Color.White else SugarTrackDarkNavy,
                            fontWeight = FontWeight.ExtraBold
                        )
                    ) {
                        append("Sugar")
                    }
                    withStyle(
                        SpanStyle(
                            color = if (isDark) SugarTrackLightBlue else SugarTrackPrimaryBlue,
                            fontWeight = FontWeight.ExtraBold
                        )
                    ) {
                        append("Track")
                    }
                },
                fontSize = if (iconSize >= 48.dp) 24.sp else 20.sp,
                letterSpacing = (-0.5).sp
            )

            if (showTagline) {
                Text(
                    text = "Track Sugar. Track Health.",
                    fontSize = if (iconSize >= 48.dp) 12.sp else 10.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isDark) SugarTrackSlateText.copy(alpha = 0.8f) else SugarTrackSlateText
                )
            }
        }
    }
}

/**
 * Centered Vertical Brand Logo for Splash & Login screens.
 */
@Composable
fun SugarTrackVerticalHeroLogo(
    modifier: Modifier = Modifier,
    iconSize: Dp = 88.dp,
    isDark: Boolean = isSystemInDarkTheme()
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SugarTrackDropIcon(
            size = iconSize,
            dropColor = SugarTrackPrimaryBlue,
            checkColor = Color.White
        )

        Spacer(Modifier.height(16.dp))

        Text(
            text = buildAnnotatedString {
                withStyle(
                    SpanStyle(
                        color = if (isDark) Color.White else SugarTrackDarkNavy,
                        fontWeight = FontWeight.Black
                    )
                ) {
                    append("Sugar")
                }
                withStyle(
                    SpanStyle(
                        color = if (isDark) SugarTrackLightBlue else SugarTrackPrimaryBlue,
                        fontWeight = FontWeight.Black
                    )
                ) {
                    append("Track")
                }
            },
            fontSize = 34.sp,
            letterSpacing = (-1).sp
        )

        Spacer(Modifier.height(4.dp))

        Text(
            text = "Track Sugar. Track Health.",
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            color = if (isDark) Color(0xFF94A3B8) else SugarTrackSlateText
        )
    }
}
