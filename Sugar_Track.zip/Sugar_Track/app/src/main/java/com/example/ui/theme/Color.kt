package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Official SugarTrack Brand Palette (from Brand Identity Master)
val SugarTrackPrimaryBlue = Color(0xFF2563EB)     // Brand Primary Blue #2563EB
val SugarTrackLightBlue = Color(0xFF60A5FA)       // Secondary Light Blue #60A5FA
val SugarTrackSuccessGreen = Color(0xFF22C55E)    // Success Green #22C55E
val SugarTrackBackgroundLight = Color(0xFFF8FAFC) // Light UI Background #F8FAFC
val SugarTrackDarkNavy = Color(0xFF0F172A)        // Deep Charcoal/Dark Navy #0F172A
val SugarTrackSlateText = Color(0xFF64748B)       // Subtitle/Tagline Slate #64748B

// Aliases for compatibility
val MedicalBluePrimary = SugarTrackPrimaryBlue
val MedicalBluePrimaryDark = SugarTrackLightBlue
val MedicalBlueLight = SugarTrackLightBlue
val MedicalCyanSecondary = SugarTrackLightBlue
val MedicalCyanSecondaryDark = Color(0xFF93C5FD)

// Clinical Status & Indicator Colors
val SugarNormalGreen = SugarTrackSuccessGreen
val SugarNormalGreenBg = Color(0xFFDCFCE7)
val SugarLowAlertRed = Color(0xFFEF4444)
val SugarLowAlertRedBg = Color(0xFFFEE2E2)
val SugarHighAlertOrange = Color(0xFFF59E0B)
val SugarHighAlertOrangeBg = Color(0xFFFEF3C7)
val SugarVeryHighAlertRed = Color(0xFFDC2626)

// Surfaces & Backgrounds
val MedicalBackgroundLight = SugarTrackBackgroundLight
val MedicalSurfaceLight = Color(0xFFFFFFFF)
val MedicalSurfaceVariantLight = Color(0xFFEFF6FF)
val MedicalOutlineLight = Color(0xFFE2E8F0)

val MedicalBackgroundDark = Color(0xFF0F172A)
val MedicalSurfaceDark = Color(0xFF1E293B)
val MedicalSurfaceVariantDark = Color(0xFF334155)
val MedicalOutlineDark = Color(0xFF475569)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = SugarTrackSlateText
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
