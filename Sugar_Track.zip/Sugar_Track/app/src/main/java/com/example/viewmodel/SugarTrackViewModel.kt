package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SugarTrackDatabase
import com.example.data.entity.*
import com.example.data.repository.SugarTrackRepository
import com.example.util.AnalyticsTracker
import com.example.util.NotificationHelper
import com.example.util.PdfReportGenerator
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class SugarTrackViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SugarTrackRepository
    val context = application.applicationContext

    init {
        val database = SugarTrackDatabase.getDatabase(application, viewModelScope)
        repository = SugarTrackRepository(database)
        NotificationHelper.initNotificationChannels(application)
        AnalyticsTracker.logAppOpen()
    }

    // Auth & Session
    private val _isLoggedIn = MutableStateFlow(true) // Start authenticated/guest ready
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _userEmail = MutableStateFlow("patient@sugartrack.app")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    private val _isGuest = MutableStateFlow(false)
    val isGuest: StateFlow<Boolean> = _isGuest.asStateFlow()

    // Navigation and Tab State
    private val _currentNavIndex = MutableStateFlow(0) // 0: Home, 1: Medicines, 2: Sugar Logs, 3: Reports, 4: Profile
    val currentNavIndex: StateFlow<Int> = _currentNavIndex.asStateFlow()

    fun setNavIndex(index: Int) {
        _currentNavIndex.value = index
    }

    // Repository Flows
    val userProfile: StateFlow<UserProfileEntity?> = repository.userProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val medicines: StateFlow<List<MedicineEntity>> = repository.allMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockMedicines: StateFlow<List<MedicineEntity>> = repository.lowStockMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sugarLogs: StateFlow<List<SugarLogEntity>> = repository.allSugarLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestSugarLog: StateFlow<SugarLogEntity?> = repository.latestSugarLog
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val hba1cRecords: StateFlow<List<HbA1cEntity>> = repository.allHbA1cRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestHbA1c: StateFlow<HbA1cEntity?> = repository.latestHbA1c
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val bloodPressureRecords: StateFlow<List<BloodPressureEntity>> = repository.allBloodPressure
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val latestBloodPressure: StateFlow<BloodPressureEntity?> = repository.latestBloodPressure
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val weightRecords: StateFlow<List<WeightEntity>> = repository.allWeightRecords
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val appointments: StateFlow<List<AppointmentEntity>> = repository.allAppointments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prescriptions: StateFlow<List<PrescriptionEntity>> = repository.allPrescriptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val familyMembers: StateFlow<List<FamilyMemberEntity>> = repository.allFamilyMembers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Preferences & Flags
    val isSeniorMode = MutableStateFlow(false)
    val isDarkMode = MutableStateFlow(false)
    val appLanguage = MutableStateFlow("en")
    val isPremium = MutableStateFlow(false)
    val waterGlasses = MutableStateFlow(5)
    val dailySteps = MutableStateFlow(5420)

    // Sugar Chart Range: "7d", "30d", "90d", "all"
    val selectedChartRange = MutableStateFlow("7d")

    // Backup status message
    val syncStatusMessage = MutableStateFlow<String?>(null)

    init {
        viewModelScope.launch {
            repository.userProfile.collect { profile ->
                if (profile != null) {
                    isSeniorMode.value = profile.isSeniorMode
                    isDarkMode.value = profile.isDarkMode
                    appLanguage.value = profile.languageCode
                    isPremium.value = profile.isPremium
                }
            }
        }
    }

    // Authentication actions
    fun loginWithEmail(email: String) {
        _userEmail.value = email
        _isGuest.value = false
        _isLoggedIn.value = true
    }

    fun loginWithGoogle() {
        _userEmail.value = "google.user@gmail.com"
        _isGuest.value = false
        _isLoggedIn.value = true
    }

    fun enterGuestMode() {
        _userEmail.value = "Guest Patient"
        _isGuest.value = true
        _isLoggedIn.value = true
    }

    fun logout() {
        _isLoggedIn.value = false
    }

    // Hydration & Activity
    fun incrementWater() {
        if (waterGlasses.value < 16) waterGlasses.value += 1
    }

    fun decrementWater() {
        if (waterGlasses.value > 0) waterGlasses.value -= 1
    }

    fun addSteps(delta: Int) {
        dailySteps.value = (dailySteps.value + delta).coerceAtLeast(0)
    }

    // Medicine Operations
    fun markMedicineTaken(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.markMedicineTaken(medicine.id, taken = !medicine.takenToday)
            AnalyticsTracker.logNotificationTaken(medicine.name)
            if (!medicine.takenToday && medicine.quantityAvailable - 1 <= medicine.refillThreshold) {
                NotificationHelper.showRefillAlert(
                    context,
                    medicine.name,
                    medicine.quantityAvailable - 1
                )
            }
        }
    }

    fun markMedicineMissed(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.markMedicineMissed(medicine.id, missed = !medicine.missedToday)
            AnalyticsTracker.logNotificationMissed(medicine.name)
        }
    }

    fun snoozeMedicine(medicine: MedicineEntity, minutes: Int = 15) {
        viewModelScope.launch {
            NotificationHelper.showMedicineReminder(
                context = context,
                medicineName = "${medicine.name} (Snoozed $minutes m)",
                dosage = medicine.dosage,
                reminderTime = "In $minutes mins"
            )
            syncStatusMessage.value = "Reminder for ${medicine.name} snoozed for $minutes mins"
        }
    }

    fun refillMedicine(medicine: MedicineEntity, count: Int = 30) {
        viewModelScope.launch {
            repository.refillStock(medicine.id, count)
        }
    }

    fun addMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.insertMedicine(medicine)
            AnalyticsTracker.logAddMedicine(medicine.name, medicine.category)
        }
    }

    fun updateMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.updateMedicine(medicine)
        }
    }

    fun deleteMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.deleteMedicine(medicine)
        }
    }

    fun testReminderNotification(medicine: MedicineEntity) {
        NotificationHelper.showMedicineReminder(
            context,
            medicine.name,
            medicine.dosage,
            medicine.reminderTime
        )
    }

    // Sugar Log Operations
    fun addSugarReading(value: Double, readingType: String, notes: String = "") {
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val sdfTime = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        val log = SugarLogEntity(
            value = value,
            readingType = readingType,
            date = sdfDate.format(now),
            time = sdfTime.format(now),
            notes = notes,
            timestamp = System.currentTimeMillis()
        )
        viewModelScope.launch {
            repository.insertSugarLog(log)
            AnalyticsTracker.logSugar(value, readingType)
            if (value < 70.0) {
                NotificationHelper.showHypoAlert(context, value)
            }
        }
    }

    fun deleteSugarLog(log: SugarLogEntity) {
        viewModelScope.launch {
            repository.deleteSugarLog(log)
        }
    }

    // HbA1c Operations
    fun addHbA1c(value: Double, date: String, labName: String, notes: String) {
        viewModelScope.launch {
            repository.insertHbA1c(
                HbA1cEntity(
                    value = value,
                    testDate = date,
                    labName = labName,
                    notes = notes
                )
            )
        }
    }

    fun deleteHbA1c(record: HbA1cEntity) {
        viewModelScope.launch {
            repository.deleteHbA1c(record)
        }
    }

    // Blood Pressure Operations
    fun addBloodPressure(systolic: Int, diastolic: Int, pulse: Int, notes: String = "") {
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val sdfTime = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val now = Date()

        viewModelScope.launch {
            repository.insertBloodPressure(
                BloodPressureEntity(
                    systolic = systolic,
                    diastolic = diastolic,
                    pulse = pulse,
                    date = sdfDate.format(now),
                    time = sdfTime.format(now),
                    notes = notes
                )
            )
        }
    }

    fun deleteBloodPressure(record: BloodPressureEntity) {
        viewModelScope.launch {
            repository.deleteBloodPressure(record)
        }
    }

    // Weight Operations
    fun addWeight(weightKg: Double, notes: String = "") {
        val sdfDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        viewModelScope.launch {
            repository.insertWeight(
                WeightEntity(
                    weightKg = weightKg,
                    date = sdfDate.format(Date()),
                    notes = notes
                )
            )
        }
    }

    fun deleteWeight(record: WeightEntity) {
        viewModelScope.launch {
            repository.deleteWeight(record)
        }
    }

    // Appointments
    fun addAppointment(doctorName: String, hospital: String, date: String, time: String, notes: String) {
        viewModelScope.launch {
            repository.insertAppointment(
                AppointmentEntity(
                    doctorName = doctorName,
                    hospital = hospital,
                    date = date,
                    time = time,
                    notes = notes
                )
            )
        }
    }

    fun deleteAppointment(appointment: AppointmentEntity) {
        viewModelScope.launch {
            repository.deleteAppointment(appointment)
        }
    }

    fun testAppointmentNotification(appointment: AppointmentEntity) {
        NotificationHelper.showAppointmentReminder(
            context,
            appointment.doctorName,
            appointment.hospital,
            appointment.date,
            appointment.time
        )
    }

    // Prescriptions
    fun addPrescription(doctorName: String, date: String, notes: String, imageUri: String = "") {
        viewModelScope.launch {
            repository.insertPrescription(
                PrescriptionEntity(
                    doctorName = doctorName,
                    date = date,
                    notes = notes,
                    imageUri = imageUri
                )
            )
            AnalyticsTracker.logUploadPrescription(doctorName)
        }
    }

    fun deletePrescription(prescription: PrescriptionEntity) {
        viewModelScope.launch {
            repository.deletePrescription(prescription)
        }
    }

    // Family Members
    fun addFamilyMember(name: String, relationship: String, phone: String, email: String) {
        if (_isGuest.value) {
            syncStatusMessage.value = "Guest Mode: Family Monitoring requires an authenticated account. Please sign in."
            return
        }
        viewModelScope.launch {
            repository.insertFamilyMember(
                FamilyMemberEntity(
                    name = name,
                    relationship = relationship,
                    phone = phone,
                    email = email
                )
            )
        }
    }

    fun deleteFamilyMember(member: FamilyMemberEntity) {
        viewModelScope.launch {
            repository.deleteFamilyMember(member)
        }
    }

    // Profile & Settings
    fun updateProfile(updated: UserProfileEntity) {
        viewModelScope.launch {
            repository.saveUserProfile(updated)
            isSeniorMode.value = updated.isSeniorMode
            isDarkMode.value = updated.isDarkMode
            appLanguage.value = updated.languageCode
            isPremium.value = updated.isPremium
        }
    }

    fun toggleSeniorMode(enabled: Boolean) {
        isSeniorMode.value = enabled
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(isSeniorMode = enabled))
    }

    fun setLanguage(langCode: String) {
        appLanguage.value = langCode
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(languageCode = langCode))
    }

    fun toggleDarkMode(enabled: Boolean) {
        isDarkMode.value = enabled
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(isDarkMode = enabled))
    }

    fun upgradeToPremium() {
        isPremium.value = true
        val current = userProfile.value ?: UserProfileEntity()
        updateProfile(current.copy(isPremium = true))
        AnalyticsTracker.logPremiumPurchase()
        syncStatusMessage.value = "Unlocked SugarTrack Premium (₹99/year active)!"
    }

    fun syncCloudBackup() {
        if (_isGuest.value) {
            syncStatusMessage.value = "Guest Mode: Cloud Sync is disabled. Please sign in with Email or Google to enable backup."
            return
        }
        viewModelScope.launch {
            syncStatusMessage.value = "Syncing with Firestore Cloud Backup..."
            kotlinx.coroutines.delay(1200)
            val count = sugarLogs.value.size + medicines.value.size
            syncStatusMessage.value = "Backup successful! Synced $count records to secure cloud."
        }
    }

    fun generatePdfReport(): File? {
        AnalyticsTracker.logGenerateReport()
        return PdfReportGenerator.generateAndShareReport(
            context = context,
            profile = userProfile.value,
            sugarLogs = sugarLogs.value,
            hba1cList = hba1cRecords.value,
            medicines = medicines.value,
            bpList = bloodPressureRecords.value,
            appointments = appointments.value
        )
    }

    fun clearStatusMessage() {
        syncStatusMessage.value = null
    }
}
