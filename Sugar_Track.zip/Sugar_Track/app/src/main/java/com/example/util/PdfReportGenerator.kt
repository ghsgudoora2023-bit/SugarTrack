package com.example.util

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import com.example.data.entity.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object PdfReportGenerator {

    fun generateAndShareReport(
        context: Context,
        profile: UserProfileEntity?,
        sugarLogs: List<SugarLogEntity>,
        hba1cList: List<HbA1cEntity>,
        medicines: List<MedicineEntity>,
        bpList: List<BloodPressureEntity>,
        appointments: List<AppointmentEntity>,
        reportTitle: String = "SugarTrack Comprehensive Diabetes Health Report"
    ): File? {
        try {
            val pdfDoc = PdfDocument()
            val pageWidth = 595 // Standard A4 width at 72dpi
            val pageHeight = 842 // Standard A4 height at 72dpi

            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
            val page = pdfDoc.startPage(pageInfo)
            val canvas = page.canvas

            val paint = Paint().apply { isAntiAlias = true }

            // Header Background Banner
            paint.color = Color.parseColor("#0D47A1")
            canvas.drawRect(0f, 0f, pageWidth.toFloat(), 90f, paint)

            // Header Title
            paint.color = Color.WHITE
            paint.textSize = 20f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("SugarTrack Medical Summary", 24f, 40f, paint)

            paint.textSize = 11f
            paint.typeface = Typeface.DEFAULT
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            canvas.drawText("Track Sugar. Track Health. | Generated: ${sdf.format(Date())}", 24f, 62f, paint)

            var y = 115f

            // Patient Info Box
            paint.color = Color.parseColor("#F0F4F8")
            canvas.drawRoundRect(20f, y, pageWidth - 20f, y + 80f, 8f, 8f, paint)

            paint.color = Color.parseColor("#102030")
            paint.textSize = 13f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("Patient: ${profile?.name ?: "Sarah Jenkins"}", 35f, y + 26f, paint)

            paint.textSize = 10.5f
            paint.typeface = Typeface.DEFAULT
            val line1 = "Age: ${profile?.age ?: 62} yrs | Gender: ${profile?.gender ?: "Female"} | Condition: ${profile?.diabetesType ?: "Type 2 Diabetes"}"
            canvas.drawText(line1, 35f, y + 46f, paint)

            val line2 = "Doctor: ${profile?.doctorName ?: "Dr. Michael Chen, MD"} | Emergency: ${profile?.emergencyContactName ?: "David"} (${profile?.emergencyContactPhone ?: ""})"
            canvas.drawText(line2, 35f, y + 64f, paint)

            y += 105f

            // Section: Recent Blood Glucose Readings
            paint.color = Color.parseColor("#0D47A1")
            paint.textSize = 13f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("1. Blood Glucose History (Latest ${sugarLogs.take(8).size} Logs)", 24f, y, paint)
            y += 18f

            // Table Header
            paint.color = Color.parseColor("#E1ECF7")
            canvas.drawRect(20f, y, pageWidth - 20f, y + 20f, paint)
            paint.color = Color.parseColor("#003366")
            paint.textSize = 10f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("Date & Time", 30f, y + 14f, paint)
            canvas.drawText("Meal Type", 180f, y + 14f, paint)
            canvas.drawText("Value (mg/dL)", 300f, y + 14f, paint)
            canvas.drawText("Status", 420f, y + 14f, paint)
            y += 24f

            paint.typeface = Typeface.DEFAULT
            for (log in sugarLogs.take(7)) {
                paint.color = Color.parseColor("#222222")
                canvas.drawText("${log.date} ${log.time}", 30f, y + 12f, paint)
                canvas.drawText(log.readingType, 180f, y + 12f, paint)
                canvas.drawText("${log.value.toInt()} mg/dL", 300f, y + 12f, paint)

                val status = when {
                    log.value < 70 -> "Low (Hypo)"
                    log.value <= 140 -> "Normal Target"
                    log.value <= 180 -> "Elevated"
                    else -> "High (Hyper)"
                }
                paint.color = when {
                    log.value < 70 -> Color.parseColor("#C62828")
                    log.value <= 140 -> Color.parseColor("#2E7D32")
                    else -> Color.parseColor("#EF6C00")
                }
                canvas.drawText(status, 420f, y + 12f, paint)
                y += 16f
            }

            y += 14f

            // Section: Current Active Medications
            paint.color = Color.parseColor("#0D47A1")
            paint.textSize = 13f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("2. Active Medication & Insulin Regimen", 24f, y, paint)
            y += 18f

            paint.color = Color.parseColor("#E1ECF7")
            canvas.drawRect(20f, y, pageWidth - 20f, y + 20f, paint)
            paint.color = Color.parseColor("#003366")
            paint.textSize = 10f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("Medication", 30f, y + 14f, paint)
            canvas.drawText("Dosage & Frequency", 200f, y + 14f, paint)
            canvas.drawText("Reminder", 390f, y + 14f, paint)
            canvas.drawText("Stock", 480f, y + 14f, paint)
            y += 24f

            paint.typeface = Typeface.DEFAULT
            for (med in medicines.take(5)) {
                paint.color = Color.parseColor("#222222")
                canvas.drawText(med.name, 30f, y + 12f, paint)
                canvas.drawText("${med.dosage} (${med.frequency})", 200f, y + 12f, paint)
                canvas.drawText(med.reminderTime, 390f, y + 12f, paint)
                canvas.drawText("${med.quantityAvailable} left", 480f, y + 12f, paint)
                y += 16f
            }

            y += 14f

            // Section: HbA1c & Blood Pressure
            paint.color = Color.parseColor("#0D47A1")
            paint.textSize = 13f
            paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            canvas.drawText("3. HbA1c & Vitals (Blood Pressure, Weight)", 24f, y, paint)
            y += 18f

            paint.color = Color.parseColor("#F5F9FD")
            canvas.drawRoundRect(20f, y, pageWidth - 20f, y + 58f, 6f, 6f, paint)
            paint.color = Color.parseColor("#333333")
            paint.textSize = 10.5f

            val latestHba1c = hba1cList.firstOrNull()
            val hba1cText = if (latestHba1c != null) "Latest HbA1c: ${latestHba1c.value}% on ${latestHba1c.testDate} (Target: < 7.0%)" else "HbA1c: Stable"
            canvas.drawText(hba1cText, 35f, y + 22f, paint)

            val latestBp = bpList.firstOrNull()
            val bpText = if (latestBp != null) "Blood Pressure: ${latestBp.systolic}/${latestBp.diastolic} mmHg (Pulse: ${latestBp.pulse} bpm) on ${latestBp.date}" else "Blood Pressure: Normal"
            canvas.drawText(bpText, 35f, y + 42f, paint)

            y += 75f

            // Doctor / Signature Section
            paint.color = Color.parseColor("#E0E0E0")
            canvas.drawLine(35f, y + 50f, 220f, y + 50f, paint)
            canvas.drawLine(pageWidth - 220f, y + 50f, pageWidth - 35f, y + 50f, paint)

            paint.color = Color.parseColor("#555555")
            paint.textSize = 9.5f
            canvas.drawText("Physician Signature & Stamp", 45f, y + 65f, paint)
            canvas.drawText("Patient / Caregiver Signature", pageWidth - 205f, y + 65f, paint)

            // Footer note
            paint.color = Color.parseColor("#888888")
            paint.textSize = 8.5f
            canvas.drawText("Generated securely via SugarTrack App. Consult licensed medical physician for therapy adjustments.", 24f, pageHeight - 20f, paint)

            pdfDoc.finishPage(page)

            // Save PDF to cache directory
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) reportsDir.mkdirs()

            val pdfFile = File(reportsDir, "SugarTrack_Report_${System.currentTimeMillis()}.pdf")
            val outputStream = FileOutputStream(pdfFile)
            pdfDoc.writeTo(outputStream)
            outputStream.flush()
            outputStream.close()
            pdfDoc.close()

            // Trigger Share Intent
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                pdfFile
            )

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_SUBJECT, "SugarTrack Medical Health Report - ${profile?.name ?: "Patient"}")
                putExtra(Intent.EXTRA_TEXT, "Attached is the comprehensive diabetes report generated from SugarTrack.")
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }

            context.startActivity(Intent.createChooser(shareIntent, "Share or Save SugarTrack PDF Report").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })

            return pdfFile
        } catch (e: Exception) {
            e.printStackTrace()
            return null
        }
    }
}
