package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicines")
data class MedicineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val dosage: String,             // e.g. "500 mg", "10 units"
    val frequency: String,          // e.g. "Once Daily", "Twice Daily", "Before Breakfast"
    val quantityAvailable: Int,     // pills/units left in stock
    val reminderTime: String,       // e.g. "08:00 AM"
    val reminderHour: Int = 8,
    val reminderMinute: Int = 0,
    val startDate: String,
    val endDate: String = "",
    val notes: String = "",
    val category: String,           // "Tablet", "Insulin", "Injection", "Syrup", "Other"
    val takenToday: Boolean = false,
    val missedToday: Boolean = false,
    val lastTakenTimestamp: Long = 0L,
    val refillThreshold: Int = 5
)

@Entity(tableName = "sugar_logs")
data class SugarLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val value: Double,              // in mg/dL (e.g. 110.0)
    val readingType: String,        // "Fasting", "Before Meal", "After Meal", "Random", "Bedtime"
    val date: String,               // YYYY-MM-DD
    val time: String,               // HH:mm (e.g. "08:30 AM")
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "hba1c_records")
data class HbA1cEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val value: Double,              // in % (e.g. 6.8)
    val testDate: String,           // YYYY-MM-DD
    val labName: String = "",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "blood_pressure_records")
data class BloodPressureEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val systolic: Int,              // mmHg (e.g. 120)
    val diastolic: Int,             // mmHg (e.g. 80)
    val pulse: Int,                 // bpm (e.g. 72)
    val date: String,
    val time: String,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "weight_records")
data class WeightEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weightKg: Double,           // in kg (e.g. 72.5)
    val date: String,
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "appointments")
data class AppointmentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val doctorName: String,
    val hospital: String,
    val date: String,
    val time: String,
    val notes: String = "",
    val reminder24h: Boolean = true,
    val reminder1h: Boolean = true,
    val isCompleted: Boolean = false
)

@Entity(tableName = "prescriptions")
data class PrescriptionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val doctorName: String,
    val date: String,
    val notes: String = "",
    val imageUri: String = "",      // path or drawable resource
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "family_members")
data class FamilyMemberEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val relationship: String,       // "Son", "Daughter", "Spouse", "Caregiver"
    val phone: String,
    val email: String,
    val alertOnMissedMedicine: Boolean = true,
    val alertOnAbnormalSugar: Boolean = true
)

@Entity(tableName = "user_profile")
data class UserProfileEntity(
    @PrimaryKey val id: Int = 1,
    val name: String = "John Doe",
    val email: String = "john.doe@example.com",
    val age: Int = 58,
    val gender: String = "Male",
    val heightCm: Double = 172.0,
    val weightKg: Double = 76.5,
    val diabetesType: String = "Type 2", // "Type 1", "Type 2", "Prediabetes"
    val emergencyContactName: String = "Sarah Doe",
    val emergencyContactPhone: String = "+1 555-0199",
    val doctorName: String = "Dr. Robert Smith, MD",
    val doctorPhone: String = "+1 555-0142",
    val isSeniorMode: Boolean = false,
    val languageCode: String = "en",    // "en", "hi", "ur", "ks"
    val isPremium: Boolean = false,
    val isDarkMode: Boolean = false,
    val notificationsEnabled: Boolean = true
)
